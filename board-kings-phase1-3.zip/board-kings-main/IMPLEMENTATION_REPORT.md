# IMPLEMENTATION_REPORT

## Honest summary
| Phase | Status |
|-------|--------|
| 1 Audit & fix, structure, CI | **Done** (not compiled/run here — see TEST_REPORT) |
| 2 Ludo (engine, board, dice, bots, local play) | **Done**, unverified by execution |
| 3 Domino (engine, UI, bots, scoring) | **Done**, unverified by execution |
| 4 Accounts, profiles, friends, rooms, invites | **Not started** |
| 5 Online (Supabase, sync, matchmaking, anti-cheat) | **Not started** (needs a Supabase project) |
| 6 XP / Coins / Elo / seasons / stats | **Not started** |
| 7 Final tests, perf, security review, APK/iOS | CI workflows prepared; APK/iOS **not built** |

The acceptance criteria in the master prompt (online play, protected data, tamper-proof results…) are therefore **not met yet**.

## Bugs found in the original code and how they were fixed
1. Start offsets wrong (red began at the yellow arm) → `LudoBoard.startRingIndex = [13, 26, 39, 0]` (verified numerically).
2. 52-square ring walk (skipped the home-lane entry) → 51 ring squares + 5 lane + centre.
3. Base tokens could leave on any number when tapped → rules only in `LudoEngine.move`, validated before any change.
4. Illegal tap cleared `hasRolled` allowing re-rolls → engine rejects with an exception and leaves state untouched.
5. Dice from `DateTime.now()` → `DiceSource` injected (`Random.secure()` locally; server value online).
6. No three-sixes rule, win detection, ranking, skipping finished players → implemented.
7. Stack offsets compared relative positions across colours → grouped by real board square.
8. Network images (flaticon/dicebear), fake mic/chat buttons → removed; local CustomPainter avatars/dice/tokens.
9. Empty Domino button → full Domino game.
10. `shouldRepaint` always true → static board painter never repaints.
11. CI had no analysis/tests, outdated actions → analyze + test + deploy, actions v4.

## Architecture
`lib/core` (theme, l10n, services, dice) · `lib/features/{home,settings,ludo,domino}` ·
`lib/shared/widgets`. Each game: `engine/` (pure Dart, no Flutter imports, immutable state, events, versioning),
`state/` (Riverpod controllers: animation, bots, timers), `screens/`, `widgets/`.
Ludo and Domino share no engine code or state.

## Original files
`lib/ludo_engine.dart` and `lib/ludo_screen.dart` were replaced (documented necessity: wrong geometry, rules inside
widgets, network assets). The valid ring coordinates, safe-square indexes and board look were preserved.
`lib/main.dart`, `pubspec.yaml`, `deploy.yml` were rewritten.

## Known limitations
- Never compiled here (no SDK/network). Expect to fix a few compile/lint issues on first `flutter analyze`.
- Sound = platform click + haptics only (no licensed audio files bundled). Voice chat: not active.
- No chat UI yet (belongs with online rooms, Phase 5). Settings are in-memory (no persistence).
- Domino chain wraps into rows (no snake layout); no drag-and-drop.
- Ludo local modes: free-for-all (2–4) and 2v2, vs bots or pass-and-play. Fixed teams / matchmaking / invites need the online phases.
- Android/iOS/web platform folders are generated in CI, not stored.

## Suggested next step
Provide a Supabase project and confirm the items in `RULES_DECISIONS.md`; Phase 4–5 can then start with the
schema, RLS and atomic move RPCs built on shared test vectors from the Dart engines.
