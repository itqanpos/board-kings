# BOARD KINGS

Ludo and Block Domino in Flutter (Material 3, Riverpod, GoRouter, CustomPainter). Arabic (RTL) and English.

**Current status: Phases 1–3 done (local play vs bots / pass-and-play). Online play (Supabase), accounts,
ratings and rewards are NOT implemented yet** — see `IMPLEMENTATION_REPORT.md`.

```
flutter pub get
flutter analyze
flutter test
flutter run            # platform folders: run `flutter create . --platforms web,android,ios` once
```

Docs: `RULES_DECISIONS.md` (undecided rules, switchable), `TEST_REPORT.md`, `docs/BUILD_APK.md`, `docs/SUPABASE_SETUP.md`.
