# RULES_DECISIONS — قرارات القواعد

Rules the product owner did **not** fully specify. Nothing here was invented silently: each item says what is
implemented, where it is isolated, and how to change it. **Please confirm or change each one.**

## Ludo (`lib/features/ludo/engine/`)

| # | Question | Current behaviour | Where / how to change |
|---|----------|-------------------|-----------------------|
| L1 | Track length | Token walks 51 ring squares (pos 0..50), 5 home-lane squares (51..55), centre = 56. Original code used 52 ring squares (a bug). | `LudoBoard` constants |
| L2 | Extra turn on 6 when no legal move | Still granted (literal reading of "a 6 gives an extra turn"), except on the 3rd six. | `LudoEngine.roll` |
| L3 | Third consecutive 6 | The player still makes the move; the moved token returns to base if it is on the ring (pos 0..50). Tokens in the home lane / centre stay. Captures made by that move stay captured. Turn then ends. If no legal move, turn simply ends. | `LudoEngine.move` |
| L4 | Extra turn on capture / on a token reaching the centre | **Off** (not in spec). | `LudoRules.bonusTurnOnCapture`, `bonusTurnOnTokenFinish` |
| L5 | Several opponent tokens on one non-safe square | All of them are captured. | `LudoEngine.move` |
| L6 | Own tokens stacking | Allowed, no blocking/"wall" rule. | – |
| L7 | Partner tokens (2v2) | Never captured; may share a square; no blocking. Partners sit opposite (seats 0&2 vs 1&3). **Stacking rules for partners = undecided; no special behaviour implemented.** | `LudoConfig.teamOf` |
| L8 | Moving a partner's token after you finished | **Not implemented.** A player who brought all tokens home is skipped. | `LudoEngine._endTurn` |
| L9 | Team victory (2v2) | Team wins when both (non-withdrawn) partners have all tokens home. | `_checkGameOver` |
| L10 | Free-for-all end | Ends when ≤1 player is still playing (3 winners in a 4-player game; 1 in a 2-player game). Ranking = finish order, then the remaining player, then withdrawn players (latest first). | `_checkGameOver` |
| L11 | Withdrawal | Tokens leave the board; match continues if rules above allow. A team is eliminated only when both partners withdrew. | `LudoEngine.withdraw` |
| L12 | Turn direction | Clockwise by seat: red → green → blue → yellow. Seat→colour/position is fixed. 2 players use seats 0 and 2. | `LudoBoard` |
| L13 | Turn timer | Local only: when time runs out the bot plays that action. Timer is per action (roll, then move). Server-side timeouts are Phase 5. | `LudoController` |

## Domino (`lib/features/domino/engine/`)

| # | Question | Current behaviour | Where / how to change |
|---|----------|-------------------|-----------------------|
| D1 | "Highest tile" when no double is dealt | Highest pip total; tie → larger half. | `DominoEngine._beats` |
| D2 | Must the starter open with the deciding tile? | **Yes** (standard practice). | `DominoRules.forceOpeningTile` |
| D3 | Scoring when a player goes out | Winner scores the sum of **all opponents'** remaining pips. | `DominoEngine._endRound` |
| D4 | Scoring a blocked round | Player with the fewest pips wins; scores sum of opponents' pips (default) or the difference. | `DominoRules.blockPoints` |
| D5 | Tie for fewest pips in a block | Nobody scores; a new round is dealt. | `DominoEngine._endRound` |
| D6 | Next round starter | New shuffle every round; same starter rule (D1/D2). | `startNextRound` |
| D7 | Turn direction | Increasing seat index. | `DominoEngine` |
| D8 | Match target | 100 points, first to reach it (`targetScore`). Only the round winner scores, so a single player reaches it. | `DominoRules` |
| D9 | Teams in Domino | Not specified → individual play only. | – |

## Online / not yet specified (Phase 4-6)
Fair verifiable dice, Elo K-factor / formula, XP & coin amounts, season length, matchmaking tolerances — to be
decided before implementation.
