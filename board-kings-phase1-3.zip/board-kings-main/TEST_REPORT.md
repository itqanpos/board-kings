# TEST_REPORT

## Status: tests are WRITTEN but were NOT EXECUTED in this environment

The build sandbox has **no Flutter/Dart SDK and no access to pub.dev / Google storage**, so neither
`flutter test` nor `flutter analyze` could be run. **No test is claimed to pass.** The code was reviewed by hand
(bracket balance check, import/key cross-checks with scripts, board geometry verified numerically in Python,
l10n key sets compared by script). Run `flutter pub get && flutter analyze && flutter test` locally or push to
GitHub: the `Test, Build and Deploy` workflow does exactly this before deploying.

## What exists

| File | Covers |
|------|--------|
| `test/game_rules/ludo_engine_test.dart` | Board geometry (52 connected squares, start squares, home-lane entries, 8 safe squares); config validation; leaving base only on 6; illegal move rejected; roll/move sequencing; 6 = extra turn; three sixes (token back to base, lane token stays, no-move case, reset); capture, multi-capture, safe squares, lane immunity; exact finish, overshoot, 50+6; FFA/2-player win and ranking; 2v2 partner protection and team win; withdrawal, disconnect/reconnect, idempotency; duplicate-move and stale-version rejection; history; 200 randomised full games (termination + invariants) |
| `test/game_rules/ludo_bot_test.dart` | Bot legality, capture/finish preference, dice source range |
| `test/game_rules/domino_engine_test.dart` | Set of 28; dealing 7/5; starter rules; forced opening; placement/orientation; illegal/not-in-hand moves; duplicate action; pass only without moves; block detection (2 and 3 players); scoring (both variants); tie; going out; match end; next round; 200 randomised matches (tile conservation, chain integrity) |
| `test/unit/strings_test.dart` | ar/en key parity, placeholders, every used key exists |
| `test/integration/app_smoke_test.dart` | Home → Ludo setup → game screen; Domino setup |

## Not covered yet (honest gaps)
- Performance on low-end devices and multi-screen-size golden tests (need real devices/CI).
- Online concurrency, RLS and private-hand protection against a real database (Phase 5). The engines already
  expose `expectedVersion` checks and `DominoState.toPublicView()` to support them.
- `DominoPublicView` privacy is by construction (the type has no hand field); there is no runtime test beyond hand sizes.
- Domino game screen widget test (bot timers).
