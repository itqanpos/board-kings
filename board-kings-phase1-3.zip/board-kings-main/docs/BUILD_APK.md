# Building the Android APK from GitHub Actions

The repository stores only Dart sources (no `android/`, `ios/`, `web/`). Workflows run
`flutter create . --platforms ...` to generate platform folders on the fly.

1. Push the project to GitHub (branch `main`).
2. **Actions → Build Android APK → Run workflow.**
3. Download `board-kings-apk` from the run's artifacts.

The APK is signed with the **debug key** (fine for testing, **not** for the Play Store). For release signing:
generate a keystore locally, store it Base64-encoded as a GitHub secret (e.g. `ANDROID_KEYSTORE_BASE64`,
`ANDROID_KEY_PASSWORD`, ...), and add a workflow step that decodes it and writes `android/key.properties`.
Never commit keystores or passwords (`.gitignore` already excludes them).

iOS builds need a macOS runner and Apple signing credentials; not configured yet.

Web: pushing to `main` runs tests, builds with `--base-href /board-kings/` and publishes to GitHub Pages
(enable Pages → "Deploy from branch → gh-pages").
