# Supabase setup — STATUS: NOT IMPLEMENTED YET (Phase 4–6)

This project does not yet contain any Supabase code, migrations or keys. The "Online multiplayer" tile on the
home screen is disabled on purpose. This file records the plan so the next phase starts from the agreed design.

## Needed from you
1. A Supabase project (URL + anon key — kept in `--dart-define` / CI secrets, never in the repo).
2. Decisions in `RULES_DECISIONS.md` (dice fairness scheme, Elo/XP/coins numbers, matchmaking tolerances).

## Planned design (from the master prompt)
- Server is the single authority: PostgreSQL RPC functions apply moves atomically (row lock + `version` check +
  idempotency key), reusing the exact rules of `LudoEngine` / `DominoEngine` (to be ported to PL/pgSQL and
  verified against the Dart engines with shared test vectors).
- Row Level Security on every table; Domino hands live in a private table readable only by their owner;
  Realtime publishes only the public view (`DominoState.toPublicView()` shape).
- Transactional outbox table for important events; Edge Functions only for async jobs (never for move validation).
- Dice: server-generated with a commit-reveal (hash of seed published before the match, seed revealed after).
- Ratings kept separate: XP, Coins, Elo (per game + mode), Team Season Points.
