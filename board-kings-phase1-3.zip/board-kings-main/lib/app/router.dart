import 'package:go_router/go_router.dart';

import '../features/domino/screens/domino_game_screen.dart';
import '../features/domino/screens/domino_setup_screen.dart';
import '../features/home/home_screen.dart';
import '../features/ludo/screens/ludo_game_screen.dart';
import '../features/ludo/screens/ludo_setup_screen.dart';
import '../features/settings/settings_screen.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (context, state) => const HomeScreen()),
    GoRoute(path: '/ludo', builder: (context, state) => const LudoSetupScreen()),
    GoRoute(path: '/ludo/play', builder: (context, state) => const LudoGameScreen()),
    GoRoute(path: '/domino', builder: (context, state) => const DominoSetupScreen()),
    GoRoute(path: '/domino/play', builder: (context, state) => const DominoGameScreen()),
    GoRoute(path: '/settings', builder: (context, state) => const SettingsScreen()),
  ],
);
