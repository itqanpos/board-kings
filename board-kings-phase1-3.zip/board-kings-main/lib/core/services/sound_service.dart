import 'package:flutter/services.dart';

enum GameSound { tap, roll, move, capture, home, win }

/// Sound/haptic feedback that can be switched off.
///
/// Honest note: this uses the platform's built-in click sound and haptics
/// only. Real recorded effects require licensed audio assets, which are not
/// bundled yet (see IMPLEMENTATION_REPORT.md).
class SoundService {
  const SoundService({required this.enabled});

  final bool enabled;

  void play(GameSound sound) {
    if (!enabled) return;
    try {
      switch (sound) {
        case GameSound.tap:
        case GameSound.move:
          SystemSound.play(SystemSoundType.click);
        case GameSound.roll:
          SystemSound.play(SystemSoundType.click);
          HapticFeedback.selectionClick();
        case GameSound.capture:
          HapticFeedback.heavyImpact();
        case GameSound.home:
          HapticFeedback.mediumImpact();
        case GameSound.win:
          HapticFeedback.vibrate();
      }
    } catch (_) {
      // Feedback is best effort; never let it break gameplay.
    }
  }
}
