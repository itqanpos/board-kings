import 'dart:math';

/// Source of dice values. The game engine never generates randomness itself:
/// a value is always injected, so the engine is deterministic and testable and
/// the same engine can be driven by a server-generated value in online play.
///
/// Dice values are NEVER derived from the clock.
abstract class DiceSource {
  /// Returns an integer in the range 1..6.
  int roll();
}

/// Local dice backed by a cryptographically secure generator.
class SecureDiceSource implements DiceSource {
  SecureDiceSource([Random? random]) : _random = random ?? Random.secure();

  final Random _random;

  @override
  int roll() => _random.nextInt(6) + 1;
}
