import 'domino_engine.dart';
import 'domino_models.dart';

/// Deterministic heuristic bot: shed heavy tiles/doubles early and keep
/// options open. Always returns a legal move (or null when it must pass).
class DominoBot {
  DominoBot._();

  static DominoMove? chooseMove(DominoState state) {
    final moves = DominoEngine.legalMoves(state);
    if (moves.isEmpty) return null;
    final hand = state.hands[state.currentSeat];
    DominoMove best = moves.first;
    var bestScore = double.negativeInfinity;
    for (final m in moves) {
      final newEnd = _openEndAfter(state, m);
      final keeps = hand.where((t) => t != m.tile && newEnd != null && t.has(newEnd)).length;
      final score = m.tile.pips * 2.0 + (m.tile.isDouble ? 3 : 0) + keeps * 1.5;
      if (score > bestScore) {
        bestScore = score;
        best = m;
      }
    }
    return best;
  }

  static int? _openEndAfter(DominoState state, DominoMove m) {
    if (state.board.isEmpty) return m.tile.b;
    final end = m.end == DominoEnd.left ? state.leftEnd! : state.rightEnd!;
    return m.tile.otherSide(end);
  }
}
