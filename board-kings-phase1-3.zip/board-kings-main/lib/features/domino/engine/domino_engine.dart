import 'dart:math';

import 'domino_models.dart';

/// Pure Block Domino rules engine (no UI, no clock; randomness is injected
/// only when dealing). Illegal actions throw [DominoRuleException].
///
///  * 28 tiles; 2 players get 7 each, 3-4 players get 5 each; the remaining
///    tiles are out of play and nobody draws.
///  * The holder of the highest double starts; with no double, the holder of
///    the highest tile starts (highest pip total, ties broken by the larger
///    half).
///  * Passing is allowed only with no legal move.
///  * The round is blocked when every player passes in a row.
///  * A match runs until a player reaches [DominoRules.targetScore].
class DominoEngine {
  DominoEngine._();

  // ---------------------------------------------------------------- dealing

  static List<List<DominoTile>> deal(DominoConfig config, Random rng) {
    final tiles = DominoTile.fullSet()..shuffle(rng);
    return [
      for (var p = 0; p < config.playerCount; p++)
        List<DominoTile>.unmodifiable(
          (tiles.sublist(p * config.handSize, (p + 1) * config.handSize))..sort(),
        ),
    ];
  }

  /// Who starts and with which tile. Highest double, else highest tile.
  static ({int seat, DominoTile tile}) findStarter(List<List<DominoTile>> hands) {
    int? bestSeat;
    DominoTile? best;
    for (var seat = 0; seat < hands.length; seat++) {
      for (final t in hands[seat]) {
        if (best == null || _beats(t, best)) {
          best = t;
          bestSeat = seat;
        }
      }
    }
    return (seat: bestSeat!, tile: best!);
  }

  /// Ordering used to pick the starter: doubles beat non-doubles; among
  /// doubles the higher value wins; among non-doubles the higher pip total,
  /// then the larger half.
  static bool _beats(DominoTile x, DominoTile y) {
    if (x.isDouble != y.isDouble) return x.isDouble;
    if (x.isDouble) return x.a > y.a;
    if (x.pips != y.pips) return x.pips > y.pips;
    return x.b > y.b;
  }

  // ------------------------------------------------------------------ setup

  static DominoState newMatch(DominoConfig config, Random rng) {
    return startRoundFromHands(
      config,
      deal(config, rng),
      round: 1,
      scores: List<int>.filled(config.playerCount, 0),
      history: const [],
      version: 0,
    );
  }

  /// Starts a round from explicit hands (used by [newMatch], next rounds, the
  /// server and tests).
  static DominoState startRoundFromHands(
    DominoConfig config,
    List<List<DominoTile>> hands, {
    required int round,
    required List<int> scores,
    required List<DominoEvent> history,
    required int version,
  }) {
    final starter = findStarter(hands);
    return DominoState(
      config: config,
      hands: [for (final h in hands) List<DominoTile>.unmodifiable(h)],
      board: const [],
      currentSeat: starter.seat,
      consecutivePasses: 0,
      phase: DominoPhase.playing,
      scores: List<int>.unmodifiable(scores),
      round: round,
      result: DominoRoundResult.none,
      roundWinner: null,
      roundPoints: 0,
      openingTile: config.rules.forceOpeningTile ? starter.tile : null,
      matchWinner: null,
      version: version,
      history: [
        ...history,
        DominoEvent(DominoEventType.roundStarted, seat: starter.seat, tile: starter.tile),
      ],
    );
  }

  /// Deals the next round after [DominoPhase.roundOver].
  static DominoState startNextRound(DominoState state, Random rng) {
    if (state.phase != DominoPhase.roundOver) {
      throw const DominoRuleException(DominoErrorCode.roundNotOver);
    }
    return startRoundFromHands(
      state.config,
      deal(state.config, rng),
      round: state.round + 1,
      scores: state.scores,
      history: state.history,
      version: state.version + 1,
    );
  }

  // ------------------------------------------------------------------ moves

  static List<DominoMove> legalMoves(DominoState state, [int? seat]) {
    if (state.phase != DominoPhase.playing) return const [];
    final who = seat ?? state.currentSeat;
    final hand = state.hands[who];
    if (state.board.isEmpty) {
      final open = state.openingTile;
      if (open != null) {
        return hand.contains(open) ? [DominoMove(open, DominoEnd.right)] : const [];
      }
      return [for (final t in hand) DominoMove(t, DominoEnd.right)];
    }
    final left = state.leftEnd!;
    final right = state.rightEnd!;
    final moves = <DominoMove>[];
    for (final t in hand) {
      if (t.has(left)) moves.add(DominoMove(t, DominoEnd.left));
      if (t.has(right)) moves.add(DominoMove(t, DominoEnd.right));
    }
    return moves;
  }

  static DominoStep play(DominoState state, DominoMove move, {int? expectedVersion}) {
    _checkVersion(state, expectedVersion);
    if (state.phase != DominoPhase.playing) {
      throw const DominoRuleException(DominoErrorCode.notPlaying);
    }
    final seat = state.currentSeat;
    if (!state.hands[seat].contains(move.tile)) {
      throw DominoRuleException(DominoErrorCode.tileNotInHand, '${move.tile}');
    }
    if (!legalMoves(state).contains(move)) {
      throw DominoRuleException(DominoErrorCode.illegalMove, '$move');
    }

    final PlacedTile placed;
    final board = List<PlacedTile>.of(state.board);
    if (board.isEmpty) {
      placed = PlacedTile(move.tile, move.tile.a, move.tile.b);
      board.add(placed);
    } else if (move.end == DominoEnd.left) {
      final end = state.leftEnd!;
      // The new tile's right half must touch the current left end.
      placed = PlacedTile(move.tile, move.tile.otherSide(end), end);
      board.insert(0, placed);
    } else {
      final end = state.rightEnd!;
      placed = PlacedTile(move.tile, end, move.tile.otherSide(end));
      board.add(placed);
    }

    final hands = [for (final h in state.hands) List<DominoTile>.of(h)];
    hands[seat].remove(move.tile);
    final events = <DominoEvent>[
      DominoEvent(DominoEventType.tilePlayed, seat: seat, tile: move.tile, end: move.end),
    ];

    var next = state.copyWith(
      hands: [for (final h in hands) List<DominoTile>.unmodifiable(h)],
      board: List<PlacedTile>.unmodifiable(board),
      consecutivePasses: 0,
      openingTile: null,
      version: state.version + 1,
    );

    if (hands[seat].isEmpty) {
      next = _endRound(next, DominoRoundResult.domino, events, seat);
    } else {
      next = next.copyWith(currentSeat: (seat + 1) % state.config.playerCount);
    }
    return _finish(state, next, events);
  }

  /// Passing is only allowed when the current player has no legal move.
  static DominoStep pass(DominoState state, {int? expectedVersion}) {
    _checkVersion(state, expectedVersion);
    if (state.phase != DominoPhase.playing) {
      throw const DominoRuleException(DominoErrorCode.notPlaying);
    }
    if (legalMoves(state).isNotEmpty) {
      throw const DominoRuleException(DominoErrorCode.mustPlay);
    }
    final seat = state.currentSeat;
    final events = <DominoEvent>[DominoEvent(DominoEventType.passed, seat: seat)];
    var next = state.copyWith(
      consecutivePasses: state.consecutivePasses + 1,
      version: state.version + 1,
    );
    if (next.consecutivePasses >= state.config.playerCount) {
      next = _endRound(next, DominoRoundResult.blocked, events, null);
    } else {
      next = next.copyWith(currentSeat: (seat + 1) % state.config.playerCount);
    }
    return _finish(state, next, events);
  }

  // ---------------------------------------------------------------- scoring

  static DominoState _endRound(
    DominoState s,
    DominoRoundResult kind,
    List<DominoEvent> events,
    int? emptiedSeat,
  ) {
    final n = s.config.playerCount;
    final pips = [for (var i = 0; i < n; i++) s.pipsInHand(i)];
    var result = kind;
    int? winner;
    var points = 0;

    if (kind == DominoRoundResult.domino) {
      winner = emptiedSeat;
      points = _sumOthers(pips, winner!);
    } else {
      final lowest = pips.reduce(min);
      final lowSeats = [for (var i = 0; i < n; i++) if (pips[i] == lowest) i];
      if (lowSeats.length > 1) {
        result = DominoRoundResult.blockedTie;
      } else {
        winner = lowSeats.first;
        final others = _sumOthers(pips, winner);
        points = s.config.rules.blockPoints == BlockPoints.sumOfOpponents
            ? others
            : max(0, others - pips[winner]);
      }
    }

    final scores = List<int>.of(s.scores);
    if (winner != null) scores[winner] += points;

    switch (result) {
      case DominoRoundResult.domino:
        events.add(DominoEvent(DominoEventType.roundWon, seat: winner, points: points));
      case DominoRoundResult.blocked:
        events.add(DominoEvent(DominoEventType.roundBlocked, seat: winner, points: points));
      case DominoRoundResult.blockedTie:
        events.add(const DominoEvent(DominoEventType.roundTied, points: 0));
      case DominoRoundResult.none:
        break;
    }

    int? matchWinner;
    final target = s.config.rules.targetScore;
    if (winner != null && scores[winner] >= target) {
      matchWinner = winner;
      events.add(DominoEvent(DominoEventType.matchOver, seat: winner, points: scores[winner]));
    }

    return s.copyWith(
      phase: matchWinner != null ? DominoPhase.matchOver : DominoPhase.roundOver,
      scores: List<int>.unmodifiable(scores),
      result: result,
      roundWinner: winner,
      roundPoints: points,
      matchWinner: matchWinner,
    );
  }

  static int _sumOthers(List<int> pips, int winner) {
    var sum = 0;
    for (var i = 0; i < pips.length; i++) {
      if (i != winner) sum += pips[i];
    }
    return sum;
  }

  // ---------------------------------------------------------------- helpers

  static void _checkVersion(DominoState state, int? expected) {
    if (expected != null && expected != state.version) {
      throw DominoRuleException(DominoErrorCode.staleVersion,
          'expected $expected, state is ${state.version}');
    }
  }

  static DominoStep _finish(DominoState before, DominoState after, List<DominoEvent> events) {
    return DominoStep(
      after.copyWith(history: [...before.history, ...events]),
      List.unmodifiable(events),
    );
  }
}
