/// Models for Block Domino. Independent from Ludo (no shared code or state).

class DominoTile implements Comparable<DominoTile> {
  /// Normalised so that a <= b. [DominoTile(6, 2)] equals [DominoTile(2, 6)].
  factory DominoTile(int x, int y) {
    if (x < 0 || x > 6 || y < 0 || y > 6) {
      throw ArgumentError('Domino values must be 0..6');
    }
    return x <= y ? DominoTile._(x, y) : DominoTile._(y, x);
  }

  const DominoTile._(this.a, this.b);

  final int a;
  final int b;

  int get pips => a + b;
  bool get isDouble => a == b;
  bool has(int value) => a == value || b == value;

  /// Unique id 0..48 (only 28 are used).
  int get id => a * 7 + b;

  /// The other half given one half value.
  int otherSide(int value) => a == value ? b : a;

  static List<DominoTile> fullSet() => [
        for (var i = 0; i <= 6; i++)
          for (var j = i; j <= 6; j++) DominoTile(i, j),
      ];

  @override
  bool operator ==(Object other) => other is DominoTile && other.a == a && other.b == b;

  @override
  int get hashCode => id;

  @override
  int compareTo(DominoTile other) => id.compareTo(other.id);

  @override
  String toString() => '[$a|$b]';
}

/// A tile on the table, oriented as laid left-to-right.
class PlacedTile {
  const PlacedTile(this.tile, this.left, this.right);

  final DominoTile tile;
  final int left;
  final int right;

  bool get isDouble => tile.isDouble;

  @override
  String toString() => '[$left|$right]';
}

enum DominoEnd { left, right }

class DominoMove {
  const DominoMove(this.tile, this.end);

  final DominoTile tile;
  final DominoEnd end;

  @override
  bool operator ==(Object other) =>
      other is DominoMove && other.tile == tile && other.end == end;

  @override
  int get hashCode => Object.hash(tile, end);

  @override
  String toString() => 'Move($tile,$end)';
}

enum DominoPhase { playing, roundOver, matchOver }

enum DominoRoundResult { none, domino, blocked, blockedTie }

/// How a blocked game is scored. The product owner has not decided this yet,
/// so it is a switch (see RULES_DECISIONS.md).
enum BlockPoints {
  /// Winner scores the sum of every opponent's remaining pips.
  sumOfOpponents,

  /// Winner scores (sum of opponents' pips) - (winner's own pips).
  difference,
}

class DominoRules {
  const DominoRules({
    this.targetScore = 100,
    this.forceOpeningTile = true,
    this.blockPoints = BlockPoints.sumOfOpponents,
  });

  final int targetScore;

  /// The starter must open with the tile that decided who starts.
  final bool forceOpeningTile;
  final BlockPoints blockPoints;
}

class DominoConfig {
  DominoConfig({
    required this.names,
    this.rules = const DominoRules(),
  }) {
    if (names.length < 2 || names.length > 4) {
      throw ArgumentError('Domino needs 2 to 4 players');
    }
  }

  final List<String> names;
  final DominoRules rules;

  int get playerCount => names.length;

  /// 7 tiles each for 2 players, 5 each for 3 or 4.
  int get handSize => playerCount == 2 ? 7 : 5;
}

enum DominoErrorCode {
  notPlaying,
  roundNotOver,
  tileNotInHand,
  illegalMove,
  mustPlay,
  staleVersion,
}

class DominoRuleException implements Exception {
  const DominoRuleException(this.code, [this.message = '']);

  final DominoErrorCode code;
  final String message;

  @override
  String toString() => 'DominoRuleException($code${message.isEmpty ? '' : ': $message'})';
}

enum DominoEventType {
  roundStarted,
  tilePlayed,
  passed,
  roundWon,
  roundBlocked,
  roundTied,
  matchOver,
}

class DominoEvent {
  const DominoEvent(this.type, {this.seat, this.tile, this.end, this.points});

  final DominoEventType type;
  final int? seat;
  final DominoTile? tile;
  final DominoEnd? end;
  final int? points;

  @override
  String toString() => 'DominoEvent($type seat=$seat tile=$tile end=$end pts=$points)';
}

const Object _keep = Object();

/// Full server-side state, INCLUDING every hand. Never send this to clients:
/// use [DominoPublicView] (and each player's own hand) instead.
class DominoState {
  const DominoState({
    required this.config,
    required this.hands,
    required this.board,
    required this.currentSeat,
    required this.consecutivePasses,
    required this.phase,
    required this.scores,
    required this.round,
    required this.result,
    required this.roundWinner,
    required this.roundPoints,
    required this.openingTile,
    required this.matchWinner,
    required this.version,
    required this.history,
  });

  final DominoConfig config;

  /// PRIVATE: hands[seat].
  final List<List<DominoTile>> hands;
  final List<PlacedTile> board;
  final int currentSeat;
  final int consecutivePasses;
  final DominoPhase phase;

  /// Match scores per seat.
  final List<int> scores;
  final int round;
  final DominoRoundResult result;
  final int? roundWinner;
  final int roundPoints;

  /// The tile the starter must open with (when rules force it).
  final DominoTile? openingTile;
  final int? matchWinner;
  final int version;
  final List<DominoEvent> history;

  int? get leftEnd => board.isEmpty ? null : board.first.left;
  int? get rightEnd => board.isEmpty ? null : board.last.right;

  int pipsInHand(int seat) => hands[seat].fold(0, (sum, t) => sum + t.pips);

  DominoPublicView toPublicView() => DominoPublicView(
        board: board,
        currentSeat: currentSeat,
        handSizes: [for (final h in hands) h.length],
        scores: scores,
        consecutivePasses: consecutivePasses,
        phase: phase,
        round: round,
        result: result,
        roundWinner: roundWinner,
        roundPoints: roundPoints,
        matchWinner: matchWinner,
        version: version,
      );

  DominoState copyWith({
    List<List<DominoTile>>? hands,
    List<PlacedTile>? board,
    int? currentSeat,
    int? consecutivePasses,
    DominoPhase? phase,
    List<int>? scores,
    int? round,
    DominoRoundResult? result,
    Object? roundWinner = _keep,
    int? roundPoints,
    Object? openingTile = _keep,
    Object? matchWinner = _keep,
    int? version,
    List<DominoEvent>? history,
  }) {
    return DominoState(
      config: config,
      hands: hands ?? this.hands,
      board: board ?? this.board,
      currentSeat: currentSeat ?? this.currentSeat,
      consecutivePasses: consecutivePasses ?? this.consecutivePasses,
      phase: phase ?? this.phase,
      scores: scores ?? this.scores,
      round: round ?? this.round,
      result: result ?? this.result,
      roundWinner: identical(roundWinner, _keep) ? this.roundWinner : roundWinner as int?,
      roundPoints: roundPoints ?? this.roundPoints,
      openingTile:
          identical(openingTile, _keep) ? this.openingTile : openingTile as DominoTile?,
      matchWinner: identical(matchWinner, _keep) ? this.matchWinner : matchWinner as int?,
      version: version ?? this.version,
      history: history ?? this.history,
    );
  }
}

/// What every client may see: no tile identities of other players' hands.
class DominoPublicView {
  const DominoPublicView({
    required this.board,
    required this.currentSeat,
    required this.handSizes,
    required this.scores,
    required this.consecutivePasses,
    required this.phase,
    required this.round,
    required this.result,
    required this.roundWinner,
    required this.roundPoints,
    required this.matchWinner,
    required this.version,
  });

  final List<PlacedTile> board;
  final int currentSeat;
  final List<int> handSizes;
  final List<int> scores;
  final int consecutivePasses;
  final DominoPhase phase;
  final int round;
  final DominoRoundResult result;
  final int? roundWinner;
  final int roundPoints;
  final int? matchWinner;
  final int version;
}

class DominoStep {
  const DominoStep(this.state, this.events);

  final DominoState state;
  final List<DominoEvent> events;
}
