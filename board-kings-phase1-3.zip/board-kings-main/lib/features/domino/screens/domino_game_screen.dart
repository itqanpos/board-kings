import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/avatar.dart';
import '../../../shared/widgets/confetti.dart';
import '../../../shared/widgets/dialogs.dart';
import '../../settings/settings_providers.dart';
import '../engine/domino_engine.dart';
import '../engine/domino_models.dart';
import '../state/domino_controller.dart';
import '../widgets/domino_tile_view.dart';

class DominoGameScreen extends ConsumerWidget {
  const DominoGameScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ui = ref.watch(dominoControllerProvider);
    final ctrl = ref.read(dominoControllerProvider.notifier);
    final s = ref.watch(stringsProvider);
    final game = ui.game;
    final cfg = game.config;
    final over = game.phase != DominoPhase.playing;
    final humanTurn = !over && game.currentSeat == dominoHumanSeat;
    final legal = humanTurn ? DominoEngine.legalMoves(game) : const <DominoMove>[];
    final legalTiles = legal.map((m) => m.tile).toSet();
    final myHand = game.hands[dominoHumanSeat];

    String status;
    if (over) {
      status = '';
    } else if (humanTurn) {
      status = legal.isEmpty ? s.t('domino.pass') : s.t('domino.tapTile');
    } else {
      status = s.t('ludo.turnOf', {'name': cfg.names[game.currentSeat]});
    }

    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.felt, AppColors.feltDark],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  _TopBar(s: s, round: game.round),
                  // Opponents (and you) with scores and tile counts.
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    child: Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        for (var i = 0; i < cfg.playerCount; i++)
                          _PlayerChip(
                            name: cfg.names[i],
                            avatarId: i * 2 + 1,
                            score: game.scores[i],
                            tiles: game.hands[i].length,
                            tilesLabel: s.t('domino.tiles', {'n': '${game.hands[i].length}'}),
                            active: !over && game.currentSeat == i,
                            isBot: i != dominoHumanSeat,
                          ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: LayoutBuilder(builder: (context, c) {
                      final len = c.maxWidth < 420 ? 44.0 : 56.0;
                      return Center(
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.all(12),
                          child: game.board.isEmpty
                              ? Text(s.t('domino.emptyBoard'),
                                  style: const TextStyle(color: Colors.white70))
                              : Wrap(
                                  alignment: WrapAlignment.center,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  spacing: 3,
                                  runSpacing: 8,
                                  children: [
                                    for (final p in game.board)
                                      DominoTileView(
                                        first: p.left,
                                        second: p.right,
                                        length: len,
                                        vertical: p.isDouble,
                                        highlight: p.tile == ui.lastPlayed
                                            ? AppColors.goldSoft
                                            : null,
                                      ),
                                  ],
                                ),
                        ),
                      );
                    }),
                  ),
                  SizedBox(
                    height: 26,
                    child: ui.notice == null
                        ? null
                        : Text(
                            s.t(ui.notice!.key, ui.notice!.args),
                            style: const TextStyle(
                                color: AppColors.goldSoft, fontWeight: FontWeight.bold),
                          ),
                  ),
                  if (ui.selected != null)
                    _EndChooser(
                      s: s,
                      leftValue: game.leftEnd!,
                      rightValue: game.rightEnd!,
                      onLeft: () => ctrl.chooseEnd(DominoEnd.left),
                      onRight: () => ctrl.chooseEnd(DominoEnd.right),
                      onCancel: ctrl.cancelSelection,
                    ),
                  Text(status, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                  const SizedBox(height: 6),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
                    child: Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        for (final tile in myHand)
                          GestureDetector(
                            onTap: () => ctrl.selectTile(tile),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              transform: Matrix4.translationValues(
                                  0, ui.selected == tile ? -10 : 0, 0),
                              child: DominoTileView(
                                first: tile.a,
                                second: tile.b,
                                length: 64,
                                vertical: true,
                                highlight: legalTiles.contains(tile)
                                    ? AppColors.gold
                                    : null,
                                dimmed: humanTurn && !legalTiles.contains(tile),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
              if (over) ...[
                if (game.phase == DominoPhase.matchOver)
                  const Positioned.fill(child: ConfettiOverlay()),
                Positioned.fill(
                  child: _ResultOverlay(
                    game: game,
                    s: s,
                    onNext: ctrl.nextRound,
                    onAgain: ctrl.restart,
                    onHome: () => context.go('/'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _TopBar extends ConsumerWidget {
  const _TopBar({required this.s, required this.round});

  final Strings s;
  final int round;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sound = ref.watch(soundEnabledProvider);
    return Row(
      children: [
        IconButton(
          tooltip: s.t('common.back'),
          icon: const Icon(Icons.arrow_back),
          onPressed: () async {
            final leave = await confirmLeave(context, s);
            if (leave && context.mounted) context.go('/domino');
          },
        ),
        Expanded(
          child: Text(
            '${s.t('domino.title')} • ${s.t('domino.round', {'n': '$round'})}',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
        ),
        IconButton(
          tooltip: s.t('settings.sound'),
          icon: Icon(sound ? Icons.volume_up : Icons.volume_off),
          onPressed: () => ref.read(soundEnabledProvider.notifier).state = !sound,
        ),
        IconButton(
          tooltip: s.t('common.rules'),
          icon: const Icon(Icons.menu_book),
          onPressed: () => showRules(context, s, 'domino'),
        ),
      ],
    );
  }
}

class _PlayerChip extends StatelessWidget {
  const _PlayerChip({
    required this.name,
    required this.avatarId,
    required this.score,
    required this.tiles,
    required this.tilesLabel,
    required this.active,
    required this.isBot,
  });

  final String name;
  final int avatarId;
  final int score;
  final int tiles;
  final String tilesLabel;
  final bool active;
  final bool isBot;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: active ? AppColors.gold.withAlpha(45) : Colors.white.withAlpha(12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: active ? AppColors.gold : Colors.white12, width: active ? 2 : 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          PlayerAvatar(
            avatarId: avatarId,
            size: 38,
            ringColor: active ? AppColors.gold : null,
            glow: active,
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  if (isBot)
                    const Padding(
                      padding: EdgeInsetsDirectional.only(start: 4),
                      child: Icon(Icons.smart_toy, size: 13, color: Colors.white54),
                    ),
                ],
              ),
              Text('$score  •  $tilesLabel',
                  style: const TextStyle(fontSize: 11, color: Colors.white70)),
            ],
          ),
        ],
      ),
    );
  }
}

class _EndChooser extends StatelessWidget {
  const _EndChooser({
    required this.s,
    required this.leftValue,
    required this.rightValue,
    required this.onLeft,
    required this.onRight,
    required this.onCancel,
  });

  final Strings s;
  final int leftValue;
  final int rightValue;
  final VoidCallback onLeft;
  final VoidCallback onRight;
  final VoidCallback onCancel;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Text(s.t('domino.chooseEnd'), style: const TextStyle(color: Colors.white70)),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(90, 40)),
            onPressed: onLeft,
            child: Text('${s.t('domino.leftEnd')} ($leftValue)'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(90, 40)),
            onPressed: onRight,
            child: Text('${s.t('domino.rightEnd')} ($rightValue)'),
          ),
          IconButton(onPressed: onCancel, icon: const Icon(Icons.close)),
        ],
      ),
    );
  }
}

class _ResultOverlay extends StatelessWidget {
  const _ResultOverlay({
    required this.game,
    required this.s,
    required this.onNext,
    required this.onAgain,
    required this.onHome,
  });

  final DominoState game;
  final Strings s;
  final VoidCallback onNext;
  final VoidCallback onAgain;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    final names = game.config.names;
    final matchOver = game.phase == DominoPhase.matchOver;
    String text;
    switch (game.result) {
      case DominoRoundResult.domino:
        text = s.t('domino.roundOver.domino',
            {'name': names[game.roundWinner!], 'pts': '${game.roundPoints}'});
      case DominoRoundResult.blocked:
        text = s.t('domino.roundOver.blocked',
            {'name': names[game.roundWinner!], 'pts': '${game.roundPoints}'});
      case DominoRoundResult.blockedTie:
        text = s.t('domino.roundOver.blockedTie');
      case DominoRoundResult.none:
        text = '';
    }
    return ColoredBox(
      color: Colors.black.withAlpha(160),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: Card(
            margin: const EdgeInsets.all(20),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(matchOver ? Icons.emoji_events : Icons.flag,
                      size: 52, color: AppColors.gold),
                  const SizedBox(height: 8),
                  if (matchOver) ...[
                    Text(s.t('domino.matchOver'),
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    Text(s.t('domino.winner', {'name': names[game.matchWinner!]}),
                        style: const TextStyle(color: AppColors.goldSoft)),
                    const SizedBox(height: 8),
                  ],
                  Text(text, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  for (var i = 0; i < names.length; i++)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Row(
                        children: [
                          Expanded(child: Text(names[i])),
                          Text('${game.scores[i]} / ${game.config.rules.targetScore}'),
                        ],
                      ),
                    ),
                  const SizedBox(height: 16),
                  if (!matchOver)
                    FilledButton(onPressed: onNext, child: Text(s.t('domino.nextRound')))
                  else
                    FilledButton(onPressed: onAgain, child: Text(s.t('common.playAgain'))),
                  const SizedBox(height: 8),
                  TextButton(onPressed: onHome, child: Text(s.t('common.home'))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
