import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../shared/widgets/dialogs.dart';
import '../../settings/settings_providers.dart';
import '../state/domino_controller.dart';

class DominoSetupScreen extends ConsumerWidget {
  const DominoSetupScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(stringsProvider);
    final count = ref.watch(dominoPlayerCountProvider);
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(onPressed: () => context.go('/')),
        title: Text(s.t('domino.title')),
        actions: [
          IconButton(
            tooltip: s.t('common.rules'),
            icon: const Icon(Icons.menu_book),
            onPressed: () => showRules(context, s, 'domino'),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 12, bottom: 8),
                  child: Text(s.t('setup.players'),
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 2, label: Text('2')),
                    ButtonSegment(value: 3, label: Text('3')),
                    ButtonSegment(value: 4, label: Text('4')),
                  ],
                  selected: {count},
                  onSelectionChanged: (v) =>
                      ref.read(dominoPlayerCountProvider.notifier).state = v.first,
                ),
                const SizedBox(height: 8),
                Text(s.t('setup.vsBots'), style: const TextStyle(color: Colors.white60)),
                Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Text('${s.t('domino.target')}: 100',
                      style: const TextStyle(fontSize: 16)),
                ),
                const SizedBox(height: 28),
                FilledButton.icon(
                  onPressed: () => context.go('/domino/play'),
                  icon: const Icon(Icons.play_arrow),
                  label: Text(s.t('common.start')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
