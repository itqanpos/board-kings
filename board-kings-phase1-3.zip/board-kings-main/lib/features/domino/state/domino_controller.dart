import 'dart:math';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/services/sound_service.dart';
import '../../settings/settings_providers.dart';
import '../engine/domino_bot.dart';
import '../engine/domino_engine.dart';
import '../engine/domino_models.dart';

/// Number of players for the next local match (seat 0 is the human).
final dominoPlayerCountProvider = StateProvider<int>((ref) => 2);

/// Seat of the human player in local matches.
const int dominoHumanSeat = 0;

class DominoNotice {
  const DominoNotice(this.key, [this.args = const {}]);

  final String key;
  final Map<String, String> args;
}

const Object _unset = Object();

class DominoUiState {
  const DominoUiState({
    required this.game,
    this.busy = false,
    this.selected,
    this.notice,
    this.lastPlayed,
  });

  final DominoState game;
  final bool busy;

  /// Tile the human picked that can go on both ends (waiting for the end).
  final DominoTile? selected;
  final DominoNotice? notice;
  final DominoTile? lastPlayed;

  DominoUiState copyWith({
    DominoState? game,
    bool? busy,
    Object? selected = _unset,
    Object? notice = _unset,
    Object? lastPlayed = _unset,
  }) {
    return DominoUiState(
      game: game ?? this.game,
      busy: busy ?? this.busy,
      selected: identical(selected, _unset) ? this.selected : selected as DominoTile?,
      notice: identical(notice, _unset) ? this.notice : notice as DominoNotice?,
      lastPlayed:
          identical(lastPlayed, _unset) ? this.lastPlayed : lastPlayed as DominoTile?,
    );
  }
}

final dominoControllerProvider =
    NotifierProvider.autoDispose<DominoController, DominoUiState>(DominoController.new);

/// Sequences a local Domino match (human vs bots). Rules live in
/// [DominoEngine]; this class only adds timing and selection UX.
class DominoController extends AutoDisposeNotifier<DominoUiState> {
  bool _disposed = false;
  int _gen = 0;
  final Random _rng = Random.secure();

  bool _alive(int gen) => !_disposed && gen == _gen;

  SoundService get _sound => ref.read(soundServiceProvider);

  @override
  DominoUiState build() {
    _disposed = false;
    _gen++;
    ref.onDispose(() => _disposed = true);
    final count = ref.read(dominoPlayerCountProvider);
    final names = <String>[];
    final s = ref.read(stringsProvider);
    for (var i = 0; i < count; i++) {
      names.add(i == dominoHumanSeat
          ? s.t('common.you')
          : s.t('common.bot', {'n': '$i'}));
    }
    final game = DominoEngine.newMatch(DominoConfig(names: names), _rng);
    final gen = _gen;
    Future.microtask(() {
      if (_alive(gen)) _afterChange();
    });
    return DominoUiState(game: game);
  }

  void restart() => ref.invalidateSelf();

  bool get isHumanTurn =>
      state.game.phase == DominoPhase.playing &&
      state.game.currentSeat == dominoHumanSeat;

  List<DominoMove> movesFor(DominoTile tile) => DominoEngine.legalMoves(state.game)
      .where((m) => m.tile == tile)
      .toList();

  /// Human taps a tile in their hand.
  void selectTile(DominoTile tile) {
    if (!isHumanTurn || state.busy) return;
    final moves = movesFor(tile);
    if (moves.isEmpty) return;
    final ends = moves.map((m) => m.end).toSet();
    if (ends.length == 1) {
      _play(moves.first);
    } else {
      state = state.copyWith(selected: tile, notice: null);
    }
  }

  void chooseEnd(DominoEnd end) {
    final tile = state.selected;
    if (tile == null || !isHumanTurn || state.busy) return;
    final move = DominoMove(tile, end);
    if (!DominoEngine.legalMoves(state.game).contains(move)) return;
    _play(move);
  }

  void cancelSelection() => state = state.copyWith(selected: null);

  void nextRound() {
    if (state.game.phase != DominoPhase.roundOver) return;
    state = state.copyWith(
      game: DominoEngine.startNextRound(state.game, _rng),
      selected: null,
      notice: null,
      lastPlayed: null,
      busy: false,
    );
    _afterChange();
  }

  void _play(DominoMove move) {
    final game = state.game;
    final seat = game.currentSeat;
    final DominoStep step;
    try {
      step = DominoEngine.play(game, move, expectedVersion: game.version);
    } on DominoRuleException {
      return;
    }
    _sound.play(GameSound.move);
    if (step.state.phase != DominoPhase.playing) _sound.play(GameSound.win);
    state = state.copyWith(
      game: step.state,
      selected: null,
      lastPlayed: move.tile,
      notice: seat == dominoHumanSeat
          ? null
          : DominoNotice('domino.botPlayed', {'name': game.config.names[seat]}),
    );
    _afterChange();
  }

  void _pass({required bool isHuman}) {
    final game = state.game;
    final seat = game.currentSeat;
    final DominoStep step;
    try {
      step = DominoEngine.pass(game, expectedVersion: game.version);
    } on DominoRuleException {
      return;
    }
    state = state.copyWith(
      game: step.state,
      selected: null,
      notice: isHuman
          ? const DominoNotice('domino.pass')
          : DominoNotice('domino.botPassed', {'name': game.config.names[seat]}),
    );
    _afterChange();
  }

  void _afterChange() {
    final gen = _gen;
    if (!_alive(gen)) return;
    final g = state.game;
    if (g.phase != DominoPhase.playing) return;
    final humanTurn = g.currentSeat == dominoHumanSeat;
    final hasMove = DominoEngine.legalMoves(g).isNotEmpty;
    final version = g.version;

    if (humanTurn && hasMove) return; // wait for the player

    Future<void>.delayed(Duration(milliseconds: humanTurn ? 1100 : 850), () {
      if (!_alive(gen)) return;
      final s = state.game;
      if (s.version != version || s.phase != DominoPhase.playing) return;
      if (!hasMove) {
        _pass(isHuman: humanTurn);
      } else {
        final move = DominoBot.chooseMove(s);
        if (move != null) _play(move);
      }
    });
  }
}
