import 'package:flutter/material.dart';

/// A domino tile drawn with CustomPaint. [length] is the long side; the tile
/// is laid out horizontally (left half | right half) and rotated when
/// [vertical] is true (first value on top).
class DominoTileView extends StatelessWidget {
  const DominoTileView({
    super.key,
    required this.first,
    required this.second,
    this.length = 56,
    this.vertical = false,
    this.highlight,
    this.dimmed = false,
    this.faceDown = false,
  });

  final int first;
  final int second;
  final double length;
  final bool vertical;
  final Color? highlight;
  final bool dimmed;
  final bool faceDown;

  @override
  Widget build(BuildContext context) {
    final tile = SizedBox(
      width: length,
      height: length / 2,
      child: CustomPaint(
        painter: _TilePainter(first, second, highlight, faceDown),
      ),
    );
    final child = vertical ? RotatedBox(quarterTurns: 1, child: tile) : tile;
    return Opacity(opacity: dimmed ? 0.4 : 1, child: child);
  }
}

class _TilePainter extends CustomPainter {
  _TilePainter(this.a, this.b, this.highlight, this.faceDown);

  final int a;
  final int b;
  final Color? highlight;
  final bool faceDown;

  static const Map<int, List<List<int>>> _layout = {
    0: [],
    1: [[1, 1]],
    2: [[0, 0], [2, 2]],
    3: [[0, 0], [1, 1], [2, 2]],
    4: [[0, 0], [2, 0], [0, 2], [2, 2]],
    5: [[0, 0], [2, 0], [1, 1], [0, 2], [2, 2]],
    6: [[0, 0], [2, 0], [0, 1], [2, 1], [0, 2], [2, 2]],
  };

  @override
  void paint(Canvas canvas, Size size) {
    final r = RRect.fromRectAndRadius(
        Offset.zero & size, Radius.circular(size.height * 0.2));
    canvas.drawShadow(Path()..addRRect(r), Colors.black, 3, false);
    canvas.drawRRect(
      r,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: faceDown
              ? const [Color(0xFF455A64), Color(0xFF263238)]
              : const [Color(0xFFFFFFF0), Color(0xFFE8E2C8)],
        ).createShader(Offset.zero & size),
    );
    canvas.drawRRect(
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = highlight != null ? 3 : 1.2
        ..color = highlight ?? Colors.black45,
    );
    if (faceDown) return;

    // divider
    final mid = size.width / 2;
    canvas.drawLine(
      Offset(mid, size.height * 0.15),
      Offset(mid, size.height * 0.85),
      Paint()
        ..strokeWidth = 1.5
        ..color = Colors.black54,
    );
    _pips(canvas, a, Rect.fromLTWH(0, 0, mid, size.height));
    _pips(canvas, b, Rect.fromLTWH(mid, 0, mid, size.height));
  }

  void _pips(Canvas canvas, int value, Rect area) {
    final side = area.shortestSide;
    final pad = side * 0.2;
    final step = (side - 2 * pad) / 2;
    final ox = area.left + (area.width - side) / 2 + pad;
    final oy = area.top + (area.height - side) / 2 + pad;
    final paint = Paint()..color = const Color(0xFF212121);
    for (final p in _layout[value]!) {
      canvas.drawCircle(Offset(ox + p[0] * step, oy + p[1] * step), side * 0.085, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _TilePainter old) =>
      old.a != a || old.b != b || old.highlight != highlight || old.faceDown != faceDown;
}
