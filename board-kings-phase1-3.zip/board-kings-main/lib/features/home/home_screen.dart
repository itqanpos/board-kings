import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_theme.dart';
import '../settings/settings_providers.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(stringsProvider);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const SizedBox(height: 12),
                const Icon(Icons.casino, size: 64, color: AppColors.gold),
                const SizedBox(height: 8),
                Text(
                  s.t('app.name'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.bold,
                    color: AppColors.gold,
                    letterSpacing: 2,
                  ),
                ),
                Text(
                  s.t('home.tagline'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white60, fontSize: 15),
                ),
                const SizedBox(height: 28),
                _GameTile(
                  icon: Icons.grid_view_rounded,
                  title: s.t('home.ludo'),
                  subtitle: s.t('home.ludo.sub'),
                  color: const Color(0xFFE53935),
                  onTap: () => context.go('/ludo'),
                ),
                const SizedBox(height: 14),
                _GameTile(
                  icon: Icons.view_module_rounded,
                  title: s.t('home.domino'),
                  subtitle: s.t('home.domino.sub'),
                  color: const Color(0xFF1E88E5),
                  onTap: () => context.go('/domino'),
                ),
                const SizedBox(height: 14),
                _GameTile(
                  icon: Icons.public,
                  title: s.t('home.online'),
                  subtitle: s.t('home.online.sub'),
                  color: Colors.grey,
                  onTap: null, // genuinely unavailable until Phase 5 (Supabase)
                ),
                const SizedBox(height: 14),
                _GameTile(
                  icon: Icons.settings,
                  title: s.t('home.settings'),
                  subtitle: '',
                  color: AppColors.gold,
                  onTap: () => context.go('/settings'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GameTile extends StatelessWidget {
  const _GameTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: Material(
        color: AppColors.navyLight,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: color.withAlpha(50),
                  child: Icon(icon, color: color, size: 30),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      if (subtitle.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(subtitle,
                              style: const TextStyle(color: Colors.white60, fontSize: 13)),
                        ),
                    ],
                  ),
                ),
                if (enabled) const Icon(Icons.chevron_right, color: Colors.white38),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
