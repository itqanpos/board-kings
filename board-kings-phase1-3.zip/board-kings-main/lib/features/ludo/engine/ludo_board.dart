/// Pure geometry of the Ludo board (15 x 15 grid). No Flutter imports so the
/// same data can be used by the engine, the painter and (later) the server.
///
/// Position encoding for a token (relative to its owner's seat):
///   -1        : in base (home yard)
///   0..50     : on the shared ring (51 squares, 0 = the seat's start square)
///   51..55    : in the private home lane (5 squares)
///   56        : finished (centre)
class GridPoint {
  const GridPoint(this.x, this.y);

  final double x;
  final double y;

  @override
  bool operator ==(Object other) =>
      other is GridPoint && other.x == x && other.y == y;

  @override
  int get hashCode => Object.hash(x, y);

  @override
  String toString() => 'GridPoint($x, $y)';
}

class LudoBoard {
  LudoBoard._();

  static const int gridSize = 15;
  static const int ringLength = 52;
  static const int basePos = -1;
  static const int lastRingPos = 50;
  static const int firstLanePos = 51;
  static const int lastLanePos = 55;
  static const int finishPos = 56;
  static const int tokensPerPlayer = 4;
  static const int seatCount = 4;

  /// Seat order is clockwise starting at the top-left.
  static const List<String> seatColorNames = ['red', 'green', 'blue', 'yellow'];

  /// The 52 ring squares as [column, row]. Consecutive entries are always
  /// touching (edge or corner) and the last connects back to the first.
  static const List<List<int>> ring = [
    [6, 13], [6, 12], [6, 11], [6, 10], [6, 9], [5, 8], [4, 8], [3, 8],
    [2, 8], [1, 8], [0, 8], [0, 7], [0, 6], [1, 6], [2, 6], [3, 6],
    [4, 6], [5, 6], [6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0],
    [7, 0], [8, 0], [8, 1], [8, 2], [8, 3], [8, 4], [8, 5], [9, 6],
    [10, 6], [11, 6], [12, 6], [13, 6], [14, 6], [14, 7], [14, 8], [13, 8],
    [12, 8], [11, 8], [10, 8], [9, 8], [8, 9], [8, 10], [8, 11], [8, 12],
    [8, 13], [8, 14], [7, 14], [6, 14],
  ];

  /// Ring index of each seat's start square (pos 0).
  /// red (1,6)=13, green (8,1)=26, blue (13,8)=39, yellow (6,13)=0.
  static const List<int> startRingIndex = [13, 26, 39, 0];

  /// 8 safe squares: the four start squares and the squares 8 steps after.
  static const List<int> safeRingIndexes = [0, 8, 13, 21, 26, 34, 39, 47];

  /// Private home lane squares per seat as [column, row] (pos 51..55).
  static const List<List<List<int>>> homeLane = [
    [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]], // red
    [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]], // green
    [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]], // blue
    [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]], // yellow
  ];

  /// Top-left corner of each seat's 6x6 base area, in grid cells.
  static const List<GridPoint> baseOrigin = [
    GridPoint(0, 0),
    GridPoint(9, 0),
    GridPoint(9, 9),
    GridPoint(0, 9),
  ];

  static const List<GridPoint> _baseSlot = [
    GridPoint(2.25, 2.25),
    GridPoint(3.75, 2.25),
    GridPoint(2.25, 3.75),
    GridPoint(3.75, 3.75),
  ];

  /// Where finished tokens rest, per seat (centre triangle).
  static const List<GridPoint> _finishAnchor = [
    GridPoint(6.75, 7.5),
    GridPoint(7.5, 6.75),
    GridPoint(8.25, 7.5),
    GridPoint(7.5, 8.25),
  ];

  /// Absolute ring index for a ring position (0..50) of [seat].
  static int ringIndex(int seat, int pos) {
    assert(pos >= 0 && pos <= lastRingPos);
    return (startRingIndex[seat] + pos) % ringLength;
  }

  static bool isSafeRingIndex(int ringIdx) => safeRingIndexes.contains(ringIdx);

  /// True when [pos] is on the shared ring (so captures are possible there).
  static bool isOnRing(int pos) => pos >= 0 && pos <= lastRingPos;

  static bool isInLane(int pos) => pos >= firstLanePos && pos <= lastLanePos;

  /// Centre of the square for a token, in grid-cell units (0..15).
  static GridPoint centerOf(int seat, int pos, int tokenIndex) {
    if (pos == basePos) {
      final o = baseOrigin[seat];
      final s = _baseSlot[tokenIndex];
      return GridPoint(o.x + s.x, o.y + s.y);
    }
    if (isOnRing(pos)) {
      final c = ring[ringIndex(seat, pos)];
      return GridPoint(c[0] + 0.5, c[1] + 0.5);
    }
    if (isInLane(pos)) {
      final c = homeLane[seat][pos - firstLanePos];
      return GridPoint(c[0] + 0.5, c[1] + 0.5);
    }
    // finished
    final a = _finishAnchor[seat];
    final spread = (tokenIndex - 1.5) * 0.2;
    return seat.isEven
        ? GridPoint(a.x, a.y + spread)
        : GridPoint(a.x + spread, a.y);
  }
}
