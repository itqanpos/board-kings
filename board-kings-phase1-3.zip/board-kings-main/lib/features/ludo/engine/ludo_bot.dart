import 'ludo_board.dart';
import 'ludo_engine.dart';
import 'ludo_models.dart';

/// Deterministic heuristic bot. It only ever chooses among legal tokens, by
/// simulating each move with the real engine. Also used to auto-play a turn
/// when a human runs out of time.
class LudoBot {
  LudoBot._();

  /// Chooses a token for the current player, or null if no move is awaited.
  static int? chooseToken(LudoState state) {
    final legal = LudoEngine.currentLegalTokens(state);
    if (legal.isEmpty) return null;
    var best = legal.first;
    var bestScore = double.negativeInfinity;
    for (final token in legal) {
      final score = _score(state, token);
      if (score > bestScore) {
        bestScore = score;
        best = token;
      }
    }
    return best;
  }

  static double _score(LudoState state, int token) {
    final seat = state.currentSeat;
    final from = state.positions[seat][token];
    final step = LudoEngine.move(state, token);
    final to = step.state.positions[seat][token];
    var score = 0.0;

    for (final e in step.events) {
      switch (e.type) {
        case LudoEventType.tokenCaptured:
          score += 80.0 * e.victims.length;
        case LudoEventType.tokenFinished:
          score += 100;
        case LudoEventType.tokenEnteredLane:
          score += 30;
        case LudoEventType.tokenLeftBase:
          score += 40;
        case LudoEventType.tripleSixPenalty:
          score -= 200;
        default:
          break;
      }
    }

    if (LudoBoard.isOnRing(to) &&
        LudoBoard.isSafeRingIndex(LudoBoard.ringIndex(seat, to))) {
      score += 15;
    }
    // Leaving a square that opponents could hit is slightly good.
    if (LudoBoard.isOnRing(from) &&
        !LudoBoard.isSafeRingIndex(LudoBoard.ringIndex(seat, from))) {
      score += 3;
    }
    // Prefer advancing the token that is furthest along (get tokens home).
    score += to / 10.0;
    return score;
  }
}
