import 'ludo_board.dart';
import 'ludo_models.dart';

/// Pure Ludo rules engine. It has no UI, timing or randomness: every method
/// takes a state (and the dice value, when relevant) and returns a new state
/// plus the events that happened. Illegal actions throw [LudoRuleException].
///
/// Rules implemented (see RULES_DECISIONS.md for the decisions behind them):
///  * a token leaves base only on a 6;
///  * a 6 grants an extra roll; the third consecutive 6 ends the turn and the
///    token moved with it goes back to base when it is on the ring;
///  * finishing needs the exact remaining distance;
///  * capturing sends the opponent back to base, except on the 8 safe squares;
///  * teammates are never captured (2v2).
class LudoEngine {
  LudoEngine._();

  static const int maxConsecutiveSixes = 3;

  // ---------------------------------------------------------------- setup

  static LudoState newGame(LudoConfig config) {
    final positions = List<List<int>>.generate(
      LudoBoard.seatCount,
      (_) => List<int>.filled(LudoBoard.tokensPerPlayer, LudoBoard.basePos),
    );
    return LudoState(
      config: config,
      positions: positions,
      currentSeat: config.seats.first,
      phase: LudoPhase.awaitingRoll,
      dice: null,
      lastDice: null,
      consecutiveSixes: 0,
      finishOrder: const [],
      withdrawn: const {},
      disconnected: const {},
      ranking: const [],
      winnerTeam: null,
      version: 0,
      history: const [],
    );
  }

  // ------------------------------------------------------------ move rules

  /// Target position for moving [pos] by [dice], or null when not allowed.
  static int? targetFor(int pos, int dice) {
    if (pos == LudoBoard.finishPos) return null;
    if (pos == LudoBoard.basePos) {
      return dice == 6 ? 0 : null;
    }
    final target = pos + dice;
    return target > LudoBoard.finishPos ? null : target;
  }

  /// Token indexes of [seat] that can legally move with [dice].
  static List<int> legalTokens(LudoState state, int seat, int dice) {
    final result = <int>[];
    for (var i = 0; i < LudoBoard.tokensPerPlayer; i++) {
      if (targetFor(state.positions[seat][i], dice) != null) result.add(i);
    }
    return result;
  }

  /// Legal tokens for the player to act, empty unless a move is awaited.
  static List<int> currentLegalTokens(LudoState state) {
    if (state.phase != LudoPhase.awaitingMove || state.dice == null) {
      return const [];
    }
    return legalTokens(state, state.currentSeat, state.dice!);
  }

  // ----------------------------------------------------------------- roll

  /// Registers a dice roll for the current player. [value] must come from a
  /// [DiceSource] (local) or from the server (online) - never from the clock.
  static LudoStep roll(LudoState state, int value, {int? expectedVersion}) {
    _checkVersion(state, expectedVersion);
    if (state.isFinished) {
      throw const LudoRuleException(LudoErrorCode.gameFinished);
    }
    if (state.phase != LudoPhase.awaitingRoll) {
      throw const LudoRuleException(LudoErrorCode.notAwaitingRoll);
    }
    if (value < 1 || value > 6) {
      throw LudoRuleException(LudoErrorCode.invalidDiceValue, '$value');
    }

    final seat = state.currentSeat;
    final events = <LudoEvent>[
      LudoEvent(LudoEventType.diceRolled, seat: seat, value: value),
    ];
    final sixes = value == 6 ? state.consecutiveSixes + 1 : 0;
    if (sixes == maxConsecutiveSixes) {
      events.add(LudoEvent(LudoEventType.tripleSix, seat: seat, value: value));
    }

    final legal = legalTokens(state, seat, value);
    if (legal.isEmpty) {
      events.add(LudoEvent(LudoEventType.noLegalMoves, seat: seat, value: value));
      final extra = value == 6 && sixes < maxConsecutiveSixes;
      var next = state.copyWith(
        dice: null,
        lastDice: value,
        consecutiveSixes: sixes,
        version: state.version + 1,
      );
      next = _endTurn(next, events, extraTurn: extra);
      return _finish(state, next, events);
    }

    final next = state.copyWith(
      phase: LudoPhase.awaitingMove,
      dice: value,
      lastDice: value,
      consecutiveSixes: sixes,
      version: state.version + 1,
    );
    return _finish(state, next, events);
  }

  // ----------------------------------------------------------------- move

  /// Moves token [tokenIndex] of the current player by the rolled value.
  static LudoStep move(LudoState state, int tokenIndex, {int? expectedVersion}) {
    _checkVersion(state, expectedVersion);
    if (state.isFinished) {
      throw const LudoRuleException(LudoErrorCode.gameFinished);
    }
    if (state.phase != LudoPhase.awaitingMove || state.dice == null) {
      throw const LudoRuleException(LudoErrorCode.notAwaitingMove);
    }
    if (tokenIndex < 0 || tokenIndex >= LudoBoard.tokensPerPlayer) {
      throw LudoRuleException(LudoErrorCode.invalidToken, '$tokenIndex');
    }

    final seat = state.currentSeat;
    final dice = state.dice!;
    final from = state.positions[seat][tokenIndex];
    final to = targetFor(from, dice);
    if (to == null) {
      throw LudoRuleException(
          LudoErrorCode.illegalMove, 'seat $seat token $tokenIndex dice $dice');
    }

    final positions = [for (final row in state.positions) List<int>.of(row)];
    positions[seat][tokenIndex] = to;
    final events = <LudoEvent>[];

    if (from == LudoBoard.basePos) {
      events.add(LudoEvent(LudoEventType.tokenLeftBase,
          seat: seat, tokenIndex: tokenIndex, from: from, to: to));
    } else {
      events.add(LudoEvent(LudoEventType.tokenMoved,
          seat: seat, tokenIndex: tokenIndex, from: from, to: to));
    }
    if (!LudoBoard.isInLane(from) && LudoBoard.isInLane(to)) {
      events.add(LudoEvent(LudoEventType.tokenEnteredLane,
          seat: seat, tokenIndex: tokenIndex, from: from, to: to));
    }

    // Capture (only on the shared ring, never on a safe square).
    var captured = false;
    if (LudoBoard.isOnRing(to)) {
      final ringIdx = LudoBoard.ringIndex(seat, to);
      if (!LudoBoard.isSafeRingIndex(ringIdx)) {
        final victims = <TokenRef>[];
        for (final other in state.config.seats) {
          if (other == seat || state.config.areTeammates(seat, other)) continue;
          for (var t = 0; t < LudoBoard.tokensPerPlayer; t++) {
            final p = positions[other][t];
            if (LudoBoard.isOnRing(p) && LudoBoard.ringIndex(other, p) == ringIdx) {
              victims.add(TokenRef(other, t));
            }
          }
        }
        for (final v in victims) {
          positions[v.seat][v.index] = LudoBoard.basePos;
        }
        if (victims.isNotEmpty) {
          captured = true;
          events.add(LudoEvent(LudoEventType.tokenCaptured,
              seat: seat, tokenIndex: tokenIndex, to: to, victims: victims));
        }
      }
    }

    var tokenFinished = false;
    if (to == LudoBoard.finishPos) {
      tokenFinished = true;
      events.add(LudoEvent(LudoEventType.tokenFinished,
          seat: seat, tokenIndex: tokenIndex, from: from, to: to));
    }

    // Third consecutive six: the moved token goes back to base if on the ring.
    final triple = state.consecutiveSixes >= maxConsecutiveSixes;
    if (triple && LudoBoard.isOnRing(positions[seat][tokenIndex])) {
      events.add(LudoEvent(LudoEventType.tripleSixPenalty,
          seat: seat,
          tokenIndex: tokenIndex,
          from: positions[seat][tokenIndex],
          to: LudoBoard.basePos));
      positions[seat][tokenIndex] = LudoBoard.basePos;
    }

    var next = state.copyWith(
      positions: positions,
      dice: null,
      version: state.version + 1,
    );

    // Player completion.
    var playerDone = false;
    if (next.hasFinished(seat) && !next.finishOrder.contains(seat)) {
      playerDone = true;
      next = next.copyWith(finishOrder: [...next.finishOrder, seat]);
      events.add(LudoEvent(LudoEventType.playerFinished,
          seat: seat, value: next.finishOrder.length));
    }

    // Game over check happens before choosing the next player.
    final over = _checkGameOver(next, events);
    if (over != null) {
      return _finish(state, over, events);
    }

    final rules = state.config.rules;
    final extra = !playerDone &&
        !triple &&
        (state.dice == 6 ||
            (captured && rules.bonusTurnOnCapture) ||
            (tokenFinished && rules.bonusTurnOnTokenFinish));
    next = _endTurn(next, events, extraTurn: extra);
    return _finish(state, next, events);
  }

  // ------------------------------------------------- withdraw / connection

  /// A player leaves the match. Their tokens leave the board.
  static LudoStep withdraw(LudoState state, int seat) {
    if (state.isFinished) {
      throw const LudoRuleException(LudoErrorCode.gameFinished);
    }
    if (!state.config.isActive(seat)) {
      throw const LudoRuleException(LudoErrorCode.unknownSeat);
    }
    if (state.withdrawn.contains(seat)) {
      return LudoStep(state, const []); // idempotent
    }
    final events = <LudoEvent>[
      LudoEvent(LudoEventType.playerWithdrawn, seat: seat),
    ];
    final positions = [for (final row in state.positions) List<int>.of(row)];
    for (var t = 0; t < LudoBoard.tokensPerPlayer; t++) {
      if (positions[seat][t] != LudoBoard.finishPos) {
        positions[seat][t] = LudoBoard.basePos;
      }
    }
    var next = state.copyWith(
      positions: positions,
      withdrawn: {...state.withdrawn, seat},
      version: state.version + 1,
    );
    final over = _checkGameOver(next, events);
    if (over != null) return _finish(state, over, events);

    if (state.currentSeat == seat) {
      next = next.copyWith(dice: null);
      next = _endTurn(next, events, extraTurn: false);
    }
    return _finish(state, next, events);
  }

  /// Marks a seat connected/disconnected. The game state itself is untouched,
  /// so a returning player resumes exactly where the match is.
  static LudoStep setConnection(LudoState state, int seat, bool connected) {
    if (!state.config.isActive(seat)) {
      throw const LudoRuleException(LudoErrorCode.unknownSeat);
    }
    final isDisconnected = state.disconnected.contains(seat);
    if (connected != isDisconnected) return LudoStep(state, const []); // no change
    final set = {...state.disconnected};
    connected ? set.remove(seat) : set.add(seat);
    final events = [
      LudoEvent(LudoEventType.playerConnectionChanged,
          seat: seat, value: connected ? 1 : 0),
    ];
    return _finish(
        state, state.copyWith(disconnected: set, version: state.version + 1), events);
  }

  // -------------------------------------------------------------- helpers

  static void _checkVersion(LudoState state, int? expected) {
    if (expected != null && expected != state.version) {
      throw LudoRuleException(LudoErrorCode.staleVersion,
          'expected $expected, state is ${state.version}');
    }
  }

  static LudoStep _finish(LudoState before, LudoState after, List<LudoEvent> events) {
    final withHistory = after.copyWith(history: [...before.history, ...events]);
    return LudoStep(withHistory, List.unmodifiable(events));
  }

  static bool _isOut(LudoState s, int seat) =>
      s.withdrawn.contains(seat) || s.hasFinished(seat);

  /// Advances to the next seat that still plays, or repeats the same seat for
  /// an extra turn.
  static LudoState _endTurn(LudoState s, List<LudoEvent> events,
      {required bool extraTurn}) {
    if (extraTurn && !_isOut(s, s.currentSeat)) {
      events.add(LudoEvent(LudoEventType.extraTurn, seat: s.currentSeat));
      return s.copyWith(phase: LudoPhase.awaitingRoll, dice: null);
    }
    final seats = s.config.seats;
    var idx = seats.indexOf(s.currentSeat);
    for (var i = 0; i < seats.length; i++) {
      idx = (idx + 1) % seats.length;
      final candidate = seats[idx];
      if (!_isOut(s, candidate)) {
        events.add(LudoEvent(LudoEventType.turnChanged, seat: candidate));
        return s.copyWith(
          currentSeat: candidate,
          phase: LudoPhase.awaitingRoll,
          dice: null,
          consecutiveSixes: 0,
        );
      }
    }
    return s.copyWith(phase: LudoPhase.awaitingRoll, dice: null);
  }

  /// Returns a finished state when the match is over, otherwise null.
  static LudoState? _checkGameOver(LudoState s, List<LudoEvent> events) {
    final cfg = s.config;
    final remaining =
        cfg.seats.where((seat) => !_isOut(s, seat)).toList(growable: false);

    int? winnerTeam;
    var over = false;

    if (cfg.mode == LudoMode.teams2v2) {
      final teams = {for (final seat in cfg.seats) cfg.teamOf(seat)};
      bool teamDone(int t) {
        final members = cfg.seats
            .where((seat) => cfg.teamOf(seat) == t && !s.withdrawn.contains(seat))
            .toList();
        return members.isNotEmpty && members.every(s.hasFinished);
      }

      bool teamAlive(int t) => cfg.seats
          .any((seat) => cfg.teamOf(seat) == t && !s.withdrawn.contains(seat));

      for (final t in teams) {
        if (teamDone(t)) {
          over = true;
          winnerTeam = t;
          break;
        }
      }
      if (!over) {
        final alive = teams.where(teamAlive).toList();
        if (alive.length <= 1) {
          over = true;
          winnerTeam = alive.isEmpty ? null : alive.first;
        }
      }
    } else {
      // Free for all: ends when at most one player is still playing
      // (three winners in a 4-player game, one in a 2-player game...).
      if (remaining.length <= 1) {
        over = true;
        winnerTeam = s.finishOrder.isEmpty ? null : s.finishOrder.first;
        if (winnerTeam == null && remaining.length == 1) {
          winnerTeam = remaining.first;
        }
      }
    }
    if (!over) return null;

    final ranking = <int>[...s.finishOrder];
    for (final seat in remaining) {
      if (!ranking.contains(seat)) ranking.add(seat);
    }
    // Teams that won with a partner still on the board: list the rest by
    // progress so the standings are always complete.
    final rest = cfg.seats
        .where((seat) => !ranking.contains(seat) && !s.withdrawn.contains(seat))
        .toList()
      ..sort((a, b) => _progress(s, b).compareTo(_progress(s, a)));
    ranking.addAll(rest);
    ranking.addAll(s.withdrawn.toList().reversed.where((x) => !ranking.contains(x)));

    events.add(LudoEvent(LudoEventType.gameOver, value: winnerTeam));
    return s.copyWith(
      phase: LudoPhase.finished,
      dice: null,
      ranking: ranking,
      winnerTeam: winnerTeam,
    );
  }

  static int _progress(LudoState s, int seat) =>
      s.positions[seat].fold<int>(0, (a, p) => a + (p < 0 ? 0 : p + 1));
}
