import 'ludo_board.dart';
import 'ludo_rules.dart';

enum LudoMode { freeForAll, teams2v2 }

enum LudoPhase { awaitingRoll, awaitingMove, finished }

enum LudoErrorCode {
  gameFinished,
  notAwaitingRoll,
  notAwaitingMove,
  invalidDiceValue,
  illegalMove,
  invalidToken,
  staleVersion,
  unknownSeat,
}

class LudoRuleException implements Exception {
  const LudoRuleException(this.code, [this.message = '']);

  final LudoErrorCode code;
  final String message;

  @override
  String toString() => 'LudoRuleException($code${message.isEmpty ? '' : ': $message'})';
}

class LudoPlayerConfig {
  const LudoPlayerConfig({
    required this.seat,
    required this.name,
    this.isBot = false,
    this.avatarId = 0,
  });

  final int seat;
  final String name;
  final bool isBot;
  final int avatarId;
}

class LudoConfig {
  LudoConfig({
    required this.mode,
    required List<LudoPlayerConfig> players,
    this.rules = const LudoRules(),
  }) : players = List.unmodifiable(
          (List<LudoPlayerConfig>.of(players)
            ..sort((a, b) => a.seat.compareTo(b.seat))),
        ) {
    if (players.length < 2 || players.length > LudoBoard.seatCount) {
      throw ArgumentError('Ludo needs 2 to 4 players');
    }
    final seats = this.players.map((p) => p.seat).toSet();
    if (seats.length != players.length ||
        seats.any((s) => s < 0 || s >= LudoBoard.seatCount)) {
      throw ArgumentError('Seats must be unique and within 0..3');
    }
    if (mode == LudoMode.teams2v2 && players.length != 4) {
      throw ArgumentError('2v2 mode needs exactly 4 players');
    }
  }

  final LudoMode mode;
  final List<LudoPlayerConfig> players;
  final LudoRules rules;

  List<int> get seats => players.map((p) => p.seat).toList(growable: false);

  bool isActive(int seat) => players.any((p) => p.seat == seat);

  LudoPlayerConfig playerAt(int seat) =>
      players.firstWhere((p) => p.seat == seat,
          orElse: () => throw const LudoRuleException(LudoErrorCode.unknownSeat));

  /// Free-for-all: every seat is its own team. 2v2: opposite seats are
  /// partners (0 & 2 versus 1 & 3).
  int teamOf(int seat) => mode == LudoMode.teams2v2 ? seat % 2 : seat;

  bool areTeammates(int a, int b) => a != b && teamOf(a) == teamOf(b);
}

enum LudoEventType {
  diceRolled,
  noLegalMoves,
  tokenLeftBase,
  tokenMoved,
  tokenEnteredLane,
  tokenFinished,
  tokenCaptured,
  tripleSix,
  tripleSixPenalty,
  extraTurn,
  turnChanged,
  playerFinished,
  playerWithdrawn,
  playerConnectionChanged,
  gameOver,
}

class TokenRef {
  const TokenRef(this.seat, this.index);

  final int seat;
  final int index;

  @override
  bool operator ==(Object other) =>
      other is TokenRef && other.seat == seat && other.index == index;

  @override
  int get hashCode => Object.hash(seat, index);

  @override
  String toString() => 'TokenRef($seat,$index)';
}

/// A thing that happened during an action. Events drive animation, sound and
/// the match history; they never carry hidden information (Ludo has none).
class LudoEvent {
  const LudoEvent(
    this.type, {
    this.seat,
    this.tokenIndex,
    this.from,
    this.to,
    this.value,
    this.victims = const [],
  });

  final LudoEventType type;
  final int? seat;
  final int? tokenIndex;
  final int? from;
  final int? to;
  final int? value;
  final List<TokenRef> victims;

  @override
  String toString() =>
      'LudoEvent($type seat=$seat token=$tokenIndex $from->$to value=$value victims=$victims)';
}

class LudoState {
  const LudoState({
    required this.config,
    required this.positions,
    required this.currentSeat,
    required this.phase,
    required this.dice,
    required this.lastDice,
    required this.consecutiveSixes,
    required this.finishOrder,
    required this.withdrawn,
    required this.disconnected,
    required this.ranking,
    required this.winnerTeam,
    required this.version,
    required this.history,
  });

  final LudoConfig config;

  /// positions[seat][tokenIndex], see [LudoBoard] for the encoding.
  /// Seats that are not playing keep all four tokens at -1 and are ignored.
  final List<List<int>> positions;
  final int currentSeat;
  final LudoPhase phase;

  /// Dice value waiting to be used (only in [LudoPhase.awaitingMove]).
  final int? dice;

  /// Last rolled value, kept for display after the turn passed.
  final int? lastDice;
  final int consecutiveSixes;

  /// Seats in the order they brought all tokens home.
  final List<int> finishOrder;
  final Set<int> withdrawn;
  final Set<int> disconnected;

  /// Final standings (seats, best first). Empty until the game is finished.
  final List<int> ranking;

  /// Winning team id when the game is finished and a team won.
  final int? winnerTeam;

  /// Incremented by every successful action; used for optimistic concurrency.
  final int version;

  /// Full event log of the match (match history).
  final List<LudoEvent> history;

  bool get isFinished => phase == LudoPhase.finished;

  int tokensHome(int seat) =>
      positions[seat].where((p) => p == LudoBoard.finishPos).length;

  bool hasFinished(int seat) => tokensHome(seat) == LudoBoard.tokensPerPlayer;

  LudoState copyWith({
    List<List<int>>? positions,
    int? currentSeat,
    LudoPhase? phase,
    Object? dice = _keep,
    Object? lastDice = _keep,
    int? consecutiveSixes,
    List<int>? finishOrder,
    Set<int>? withdrawn,
    Set<int>? disconnected,
    List<int>? ranking,
    Object? winnerTeam = _keep,
    int? version,
    List<LudoEvent>? history,
  }) {
    return LudoState(
      config: config,
      positions: positions ?? this.positions,
      currentSeat: currentSeat ?? this.currentSeat,
      phase: phase ?? this.phase,
      dice: identical(dice, _keep) ? this.dice : dice as int?,
      lastDice: identical(lastDice, _keep) ? this.lastDice : lastDice as int?,
      consecutiveSixes: consecutiveSixes ?? this.consecutiveSixes,
      finishOrder: finishOrder ?? this.finishOrder,
      withdrawn: withdrawn ?? this.withdrawn,
      disconnected: disconnected ?? this.disconnected,
      ranking: ranking ?? this.ranking,
      winnerTeam:
          identical(winnerTeam, _keep) ? this.winnerTeam : winnerTeam as int?,
      version: version ?? this.version,
      history: history ?? this.history,
    );
  }
}

const Object _keep = Object();

/// Result of one engine action: the new state plus what happened.
class LudoStep {
  const LudoStep(this.state, this.events);

  final LudoState state;
  final List<LudoEvent> events;
}
