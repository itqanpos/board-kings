/// Rule switches for rules that were NOT fully specified by the product
/// owner. Every switch here is documented in RULES_DECISIONS.md. The defaults
/// implement only what the specification states explicitly.
class LudoRules {
  const LudoRules({
    this.bonusTurnOnCapture = false,
    this.bonusTurnOnTokenFinish = false,
  });

  /// Extra roll after capturing an opponent token. Not in the spec: off.
  final bool bonusTurnOnCapture;

  /// Extra roll after a token reaches the centre. Not in the spec: off.
  final bool bonusTurnOnTokenFinish;
}
