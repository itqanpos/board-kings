import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/avatar.dart';
import '../../../shared/widgets/confetti.dart';
import '../../../shared/widgets/dialogs.dart';
import '../../settings/settings_providers.dart';
import '../engine/ludo_board.dart';
import '../engine/ludo_engine.dart';
import '../engine/ludo_models.dart';
import '../state/ludo_controller.dart';
import '../widgets/dice_view.dart';
import '../widgets/ludo_board_view.dart';
import '../widgets/ludo_palette.dart';
import '../widgets/ludo_player_panel.dart';

class LudoGameScreen extends ConsumerWidget {
  const LudoGameScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ui = ref.watch(ludoControllerProvider);
    final ctrl = ref.read(ludoControllerProvider.notifier);
    final s = ref.watch(stringsProvider);
    final game = ui.game;
    final config = game.config;

    final humanTurn =
        !game.isFinished && !config.playerAt(game.currentSeat).isBot;
    final canRoll =
        humanTurn && !ui.busy && game.phase == LudoPhase.awaitingRoll;
    final movable = <TokenRef>{};
    if (humanTurn && !ui.busy && game.phase == LudoPhase.awaitingMove) {
      for (final i in LudoEngine.currentLegalTokens(game)) {
        movable.add(TokenRef(game.currentSeat, i));
      }
    }

    final board = Padding(
      padding: const EdgeInsets.all(4),
      child: LudoBoardView(
        config: config,
        positions: ui.positions,
        movable: movable,
        onTapToken: ctrl.onTokenTap,
        effect: ui.effect,
      ),
    );

    List<Widget> panels() => [
          for (final p in config.players)
            LudoPlayerPanel(
              player: p,
              active: !game.isFinished && game.currentSeat == p.seat,
              tokensHome: game.tokensHome(p.seat),
              homeLabel: s.t('ludo.homeCount', {'n': '${game.tokensHome(p.seat)}'}),
              withdrawn: game.withdrawn.contains(p.seat),
              secondsLeft: ui.secondsLeft,
              rank: game.finishOrder.contains(p.seat)
                  ? game.finishOrder.indexOf(p.seat) + 1
                  : null,
            ),
        ];

    final controls = _Controls(
      ui: ui,
      s: s,
      canRoll: canRoll,
      onRoll: ctrl.onDiceTap,
      humanTurn: humanTurn,
    );

    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.felt, AppColors.feltDark],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  _TopBar(s: s, onRules: () => showRules(context, s, 'ludo')),
                  Expanded(
                    child: LayoutBuilder(builder: (context, c) {
                      final wide = c.maxWidth > c.maxHeight * 1.15;
                      if (wide) {
                        return Row(
                          children: [
                            Expanded(child: board),
                            SizedBox(
                              width: 280,
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Wrap(
                                      alignment: WrapAlignment.center,
                                      spacing: 8,
                                      runSpacing: 8,
                                      children: panels(),
                                    ),
                                    const SizedBox(height: 16),
                                    controls,
                                  ],
                                ),
                              ),
                            ),
                          ],
                        );
                      }
                      return Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: Wrap(
                              alignment: WrapAlignment.center,
                              spacing: 8,
                              runSpacing: 6,
                              children: panels(),
                            ),
                          ),
                          Expanded(child: board),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: controls,
                          ),
                        ],
                      );
                    }),
                  ),
                ],
              ),
              if (game.isFinished) ...[
                const Positioned.fill(child: ConfettiOverlay()),
                Positioned.fill(
                  child: _ResultOverlay(
                    game: game,
                    s: s,
                    onAgain: ctrl.restart,
                    onHome: () => context.go('/'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _TopBar extends ConsumerWidget {
  const _TopBar({required this.s, required this.onRules});

  final Strings s;
  final VoidCallback onRules;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sound = ref.watch(soundEnabledProvider);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: [
          IconButton(
            tooltip: s.t('common.back'),
            icon: const Icon(Icons.arrow_back),
            onPressed: () async {
              final leave = await confirmLeave(context, s);
              if (leave && context.mounted) context.go('/ludo');
            },
          ),
          Expanded(
            child: Text(
              s.t('ludo.title'),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          IconButton(
            tooltip: s.t('settings.sound'),
            icon: Icon(sound ? Icons.volume_up : Icons.volume_off),
            onPressed: () => ref.read(soundEnabledProvider.notifier).state = !sound,
          ),
          IconButton(
            tooltip: s.t('common.rules'),
            icon: const Icon(Icons.menu_book),
            onPressed: onRules,
          ),
        ],
      ),
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({
    required this.ui,
    required this.s,
    required this.canRoll,
    required this.onRoll,
    required this.humanTurn,
  });

  final LudoUiState ui;
  final Strings s;
  final bool canRoll;
  final VoidCallback onRoll;
  final bool humanTurn;

  @override
  Widget build(BuildContext context) {
    final game = ui.game;
    final seat = game.currentSeat;
    final accent = LudoPalette.seat[seat];
    final name = game.config.playerAt(seat).name;

    String status;
    if (game.isFinished) {
      status = '';
    } else if (!humanTurn) {
      status = s.t('ludo.botThinking');
    } else if (game.phase == LudoPhase.awaitingRoll) {
      status = s.t('ludo.tapRoll');
    } else {
      status = s.t('ludo.tapToken');
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: 24,
          child: ui.notice == null
              ? null
              : Text(
                  s.t(ui.notice!.key, ui.notice!.args),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: AppColors.goldSoft, fontSize: 15, fontWeight: FontWeight.bold),
                ),
        ),
        const SizedBox(height: 6),
        DiceView(
          value: ui.face,
          rolling: ui.rolling,
          accent: accent,
          enabled: canRoll,
          onTap: onRoll,
        ),
        const SizedBox(height: 8),
        Text(
          game.isFinished ? '' : '${s.t('ludo.turnOf', {'name': name})}  •  $status',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70, fontSize: 13),
        ),
      ],
    );
  }
}

class _ResultOverlay extends StatelessWidget {
  const _ResultOverlay({
    required this.game,
    required this.s,
    required this.onAgain,
    required this.onHome,
  });

  final LudoState game;
  final Strings s;
  final VoidCallback onAgain;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    final cfg = game.config;
    final teamMode = cfg.mode == LudoMode.teams2v2;
    String? winners;
    if (teamMode && game.winnerTeam != null) {
      winners = cfg.players
          .where((p) => cfg.teamOf(p.seat) == game.winnerTeam)
          .map((p) => p.name)
          .join(' + ');
    }
    return ColoredBox(
      color: Colors.black.withAlpha(160),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: Card(
            margin: const EdgeInsets.all(20),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.emoji_events, size: 56, color: AppColors.gold),
                  const SizedBox(height: 8),
                  Text(s.t('ludo.result.title'),
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  if (winners != null) ...[
                    const SizedBox(height: 8),
                    Text(s.t('ludo.result.winnerTeam', {'names': winners}),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppColors.goldSoft)),
                  ],
                  const SizedBox(height: 12),
                  for (var i = 0; i < game.ranking.length; i++)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 74,
                            child: Text(s.t('ludo.result.rank', {'n': '${i + 1}'}),
                                style: const TextStyle(color: Colors.white70)),
                          ),
                          PlayerAvatar(
                            avatarId: cfg.playerAt(game.ranking[i]).avatarId,
                            size: 34,
                            ringColor: LudoPalette.seat[game.ranking[i]],
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(cfg.playerAt(game.ranking[i]).name,
                                overflow: TextOverflow.ellipsis),
                          ),
                          Text('${game.tokensHome(game.ranking[i])}/${LudoBoard.tokensPerPlayer}',
                              style: const TextStyle(color: Colors.white54)),
                        ],
                      ),
                    ),
                  const SizedBox(height: 16),
                  FilledButton(onPressed: onAgain, child: Text(s.t('common.playAgain'))),
                  const SizedBox(height: 8),
                  TextButton(onPressed: onHome, child: Text(s.t('common.home'))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
