import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../shared/widgets/dialogs.dart';
import '../../settings/settings_providers.dart';
import '../engine/ludo_models.dart';
import '../state/ludo_setup.dart';

class LudoSetupScreen extends ConsumerStatefulWidget {
  const LudoSetupScreen({super.key});

  @override
  ConsumerState<LudoSetupScreen> createState() => _LudoSetupScreenState();
}

class _LudoSetupScreenState extends ConsumerState<LudoSetupScreen> {
  LudoMode _mode = LudoMode.freeForAll;
  int _count = 4;
  bool _vsBots = true;
  int _timer = 0;

  static const List<List<int>> _seatsFor = [
    [], [], [0, 2], [0, 1, 2], [0, 1, 2, 3],
  ];

  void _start() {
    final s = ref.read(stringsProvider);
    final seats = _mode == LudoMode.teams2v2 ? const [0, 1, 2, 3] : _seatsFor[_count];
    final players = <LudoPlayerConfig>[];
    for (var i = 0; i < seats.length; i++) {
      final isBot = _vsBots && i > 0;
      final name = _vsBots
          ? (i == 0 ? s.t('common.you') : s.t('common.bot', {'n': '$i'}))
          : s.t('common.player', {'n': '${i + 1}'});
      players.add(LudoPlayerConfig(
        seat: seats[i],
        name: name,
        isBot: isBot,
        avatarId: seats[i] * 3 + i,
      ));
    }
    ref.read(ludoConfigProvider.notifier).state =
        LudoConfig(mode: _mode, players: players);
    ref.read(ludoTurnSecondsProvider.notifier).state = _timer;
    context.go('/ludo/play');
  }

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(stringsProvider);
    final teams = _mode == LudoMode.teams2v2;
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(onPressed: () => context.go('/')),
        title: Text(s.t('ludo.title')),
        actions: [
          IconButton(
            tooltip: s.t('common.rules'),
            icon: const Icon(Icons.menu_book),
            onPressed: () => showRules(context, s, 'ludo'),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _Section(title: s.t('setup.mode')),
                SegmentedButton<LudoMode>(
                  segments: [
                    ButtonSegment(
                        value: LudoMode.freeForAll, label: Text(s.t('ludo.mode.ffa'))),
                    ButtonSegment(
                        value: LudoMode.teams2v2, label: Text(s.t('ludo.mode.teams'))),
                  ],
                  selected: {_mode},
                  onSelectionChanged: (v) => setState(() {
                    _mode = v.first;
                    if (_mode == LudoMode.teams2v2) _count = 4;
                  }),
                ),
                if (teams)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(s.t('ludo.teamsHint'),
                        style: const TextStyle(color: Colors.white60)),
                  ),
                _Section(title: s.t('setup.players')),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 2, label: Text('2')),
                    ButtonSegment(value: 3, label: Text('3')),
                    ButtonSegment(value: 4, label: Text('4')),
                  ],
                  selected: {_count},
                  onSelectionChanged:
                      teams ? null : (v) => setState(() => _count = v.first),
                ),
                _Section(title: s.t('setup.opponents')),
                SegmentedButton<bool>(
                  segments: [
                    ButtonSegment(value: true, label: Text(s.t('setup.vsBots'))),
                    ButtonSegment(value: false, label: Text(s.t('setup.sameDevice'))),
                  ],
                  selected: {_vsBots},
                  onSelectionChanged: (v) => setState(() => _vsBots = v.first),
                ),
                _Section(title: s.t('setup.turnTimer')),
                SegmentedButton<int>(
                  segments: [
                    ButtonSegment(value: 0, label: Text(s.t('common.off'))),
                    ButtonSegment(value: 15, label: Text(s.t('common.seconds', {'n': '15'}))),
                    ButtonSegment(value: 30, label: Text(s.t('common.seconds', {'n': '30'}))),
                  ],
                  selected: {_timer},
                  onSelectionChanged: (v) => setState(() => _timer = v.first),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(s.t('setup.timerHint'),
                      style: const TextStyle(color: Colors.white60)),
                ),
                const SizedBox(height: 28),
                FilledButton.icon(
                  onPressed: _start,
                  icon: const Icon(Icons.play_arrow),
                  label: Text(s.t('common.start')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      );
}
