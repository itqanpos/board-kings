import 'dart:async';
import 'dart:math';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/services/sound_service.dart';
import '../../settings/settings_providers.dart';
import '../engine/ludo_board.dart';
import '../engine/ludo_bot.dart';
import '../engine/ludo_engine.dart';
import '../engine/ludo_models.dart';
import '../widgets/ludo_board_view.dart';
import 'ludo_setup.dart';

/// A short message for the player, translated by the UI.
class LudoNotice {
  const LudoNotice(this.key, [this.args = const {}]);

  final String key;
  final Map<String, String> args;
}

const Object _unset = Object();

class LudoUiState {
  const LudoUiState({
    required this.game,
    this.shown,
    this.rolling = false,
    this.face,
    this.busy = false,
    this.notice,
    this.secondsLeft,
    this.effect,
  });

  /// The authoritative game state (engine).
  final LudoState game;

  /// Token positions to display while a move is being animated.
  final List<List<int>>? shown;
  final bool rolling;

  /// Dice face currently shown (cosmetic during the roll, real value after).
  final int? face;

  /// True while an animation / bot action is running (input is ignored).
  final bool busy;
  final LudoNotice? notice;
  final int? secondsLeft;
  final BoardEffect? effect;

  List<List<int>> get positions => shown ?? game.positions;

  LudoUiState copyWith({
    LudoState? game,
    Object? shown = _unset,
    bool? rolling,
    Object? face = _unset,
    bool? busy,
    Object? notice = _unset,
    Object? secondsLeft = _unset,
    Object? effect = _unset,
  }) {
    return LudoUiState(
      game: game ?? this.game,
      shown: identical(shown, _unset) ? this.shown : shown as List<List<int>>?,
      rolling: rolling ?? this.rolling,
      face: identical(face, _unset) ? this.face : face as int?,
      busy: busy ?? this.busy,
      notice: identical(notice, _unset) ? this.notice : notice as LudoNotice?,
      secondsLeft: identical(secondsLeft, _unset) ? this.secondsLeft : secondsLeft as int?,
      effect: identical(effect, _unset) ? this.effect : effect as BoardEffect?,
    );
  }
}

final ludoControllerProvider =
    NotifierProvider.autoDispose<LudoController, LudoUiState>(LudoController.new);

/// Drives a local Ludo match: dice, animation, bots, turn timer. All rules are
/// delegated to [LudoEngine]; this class only sequences UI-time behaviour.
class LudoController extends AutoDisposeNotifier<LudoUiState> {
  bool _disposed = false;
  int _gen = 0;
  int _effectId = 0;
  int _turnSeconds = 0;
  Timer? _countdown;
  final Random _cosmetic = Random();

  bool _alive(int gen) => !_disposed && gen == _gen;

  SoundService get _sound => ref.read(soundServiceProvider);

  @override
  LudoUiState build() {
    _disposed = false;
    _gen++;
    _countdown?.cancel();
    ref.onDispose(() {
      _disposed = true;
      _countdown?.cancel();
    });
    final config = ref.read(ludoConfigProvider) ?? defaultLudoConfig();
    _turnSeconds = ref.read(ludoTurnSecondsProvider);
    final gen = _gen;
    Future.microtask(() {
      if (_alive(gen)) _afterChange();
    });
    return LudoUiState(game: LudoEngine.newGame(config));
  }

  /// Starts the match over with the same configuration.
  void restart() => ref.invalidateSelf();

  bool get isHumanTurn {
    final g = state.game;
    return !g.isFinished && !g.config.playerAt(g.currentSeat).isBot;
  }

  /// Called when a human taps the dice.
  void onDiceTap() {
    if (!isHumanTurn) return;
    rollDice();
  }

  /// Called when a human taps a token.
  void onTokenTap(TokenRef token) {
    if (!isHumanTurn || token.seat != state.game.currentSeat) return;
    moveToken(token.index);
  }

  Future<void> rollDice() async {
    final gen = _gen;
    final start = state;
    if (start.busy || start.game.phase != LudoPhase.awaitingRoll) return;
    _countdown?.cancel();
    state = start.copyWith(busy: true, rolling: true, notice: null, secondsLeft: null);
    _sound.play(GameSound.roll);

    for (var i = 0; i < 9; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 60));
      if (!_alive(gen)) return;
      state = state.copyWith(face: _cosmetic.nextInt(6) + 1);
    }

    final value = ref.read(diceSourceProvider).roll();
    final game = state.game;
    final LudoStep step;
    try {
      step = LudoEngine.roll(game, value, expectedVersion: game.version);
    } on LudoRuleException {
      state = state.copyWith(busy: false, rolling: false);
      return;
    }
    state = state.copyWith(face: value, rolling: false);

    final noMoves = step.events.any((e) => e.type == LudoEventType.noLegalMoves);
    if (noMoves) {
      state = state.copyWith(notice: const LudoNotice('ludo.noMoves'));
      await Future<void>.delayed(const Duration(milliseconds: 1000));
      if (!_alive(gen)) return;
    }
    state = state.copyWith(
      game: step.state,
      busy: false,
      notice: _noticeFor(step.events, step.state),
    );
    _afterChange();
  }

  Future<void> moveToken(int tokenIndex) async {
    final gen = _gen;
    final start = state;
    if (start.busy || start.game.phase != LudoPhase.awaitingMove) return;
    final game = start.game;
    if (!LudoEngine.currentLegalTokens(game).contains(tokenIndex)) return;

    final seat = game.currentSeat;
    final LudoStep step;
    try {
      step = LudoEngine.move(game, tokenIndex, expectedVersion: game.version);
    } on LudoRuleException {
      return;
    }
    _countdown?.cancel();
    state = start.copyWith(busy: true, notice: null, secondsLeft: null);

    final moveEvent = step.events.first;
    final from = moveEvent.from!;
    final to = moveEvent.to!;
    List<List<int>> copy(List<List<int>> src) => [for (final r in src) List<int>.of(r)];
    var shown = copy(game.positions);

    if (from == LudoBoard.basePos) {
      shown[seat][tokenIndex] = 0;
      state = state.copyWith(shown: copy(shown));
      _sound.play(GameSound.move);
      await Future<void>.delayed(const Duration(milliseconds: 280));
      if (!_alive(gen)) return;
    } else {
      for (var p = from + 1; p <= to; p++) {
        shown[seat][tokenIndex] = p;
        state = state.copyWith(shown: copy(shown));
        _sound.play(GameSound.move);
        await Future<void>.delayed(const Duration(milliseconds: 140));
        if (!_alive(gen)) return;
      }
    }

    BoardEffect? effect;
    final captured = step.events.where((e) => e.type == LudoEventType.tokenCaptured);
    if (captured.isNotEmpty) {
      for (final v in captured.first.victims) {
        shown[v.seat][v.index] = LudoBoard.basePos;
      }
      effect = BoardEffect(
          id: ++_effectId, at: LudoBoard.centerOf(seat, to, tokenIndex), isCapture: true);
      _sound.play(GameSound.capture);
      state = state.copyWith(shown: copy(shown), effect: effect);
      await Future<void>.delayed(const Duration(milliseconds: 450));
      if (!_alive(gen)) return;
    }
    if (step.events.any((e) => e.type == LudoEventType.tokenFinished)) {
      effect = BoardEffect(
          id: ++_effectId, at: LudoBoard.centerOf(seat, to, tokenIndex), isCapture: false);
      _sound.play(GameSound.home);
      state = state.copyWith(effect: effect);
    }
    if (step.events.any((e) => e.type == LudoEventType.tripleSixPenalty)) {
      shown[seat][tokenIndex] = LudoBoard.basePos;
      state = state.copyWith(shown: copy(shown));
      await Future<void>.delayed(const Duration(milliseconds: 450));
      if (!_alive(gen)) return;
    }

    if (step.state.isFinished) _sound.play(GameSound.win);
    state = state.copyWith(
      game: step.state,
      shown: null,
      busy: false,
      notice: _noticeFor(step.events, step.state),
    );
    _afterChange();
  }

  LudoNotice? _noticeFor(List<LudoEvent> events, LudoState after) {
    String name(int seat) => after.config.playerAt(seat).name;
    for (final e in events) {
      if (e.type == LudoEventType.playerFinished) {
        return LudoNotice('ludo.playerFinished',
            {'name': name(e.seat!), 'rank': '${e.value}'});
      }
    }
    for (final e in events) {
      if (e.type == LudoEventType.tokenCaptured) {
        final victimSeat = e.victims.first.seat;
        return LudoNotice('ludo.captured', {'name': name(victimSeat)});
      }
    }
    for (final e in events) {
      switch (e.type) {
        case LudoEventType.tripleSix:
        case LudoEventType.tripleSixPenalty:
          return const LudoNotice('ludo.tripleSix');
        case LudoEventType.noLegalMoves:
          return const LudoNotice('ludo.noMoves');
        case LudoEventType.tokenFinished:
          return const LudoNotice('ludo.tokenHome');
        case LudoEventType.extraTurn:
          return const LudoNotice('ludo.extraTurn');
        default:
          break;
      }
    }
    return null;
  }

  // ---------------------------------------------------- scheduling helpers

  void _afterChange() {
    final gen = _gen;
    if (!_alive(gen)) return;
    _countdown?.cancel();
    final g = state.game;
    if (g.isFinished) {
      state = state.copyWith(secondsLeft: null);
      return;
    }
    final isBot = g.config.playerAt(g.currentSeat).isBot;
    if (isBot) {
      state = state.copyWith(secondsLeft: null);
      _scheduleBot(gen, g.version);
      return;
    }
    if (_turnSeconds > 0) {
      state = state.copyWith(secondsLeft: _turnSeconds);
      _countdown = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (!_alive(gen)) {
          timer.cancel();
          return;
        }
        final s = state;
        if (s.busy) return;
        final left = (s.secondsLeft ?? _turnSeconds) - 1;
        if (left <= 0) {
          timer.cancel();
          state = s.copyWith(secondsLeft: null);
          _autoPlayTurn();
        } else {
          state = s.copyWith(secondsLeft: left);
        }
      });
    }
  }

  void _scheduleBot(int gen, int version) {
    Future<void>.delayed(const Duration(milliseconds: 650), () async {
      if (!_alive(gen)) return;
      final s = state;
      if (s.busy || s.game.version != version || s.game.isFinished) return;
      if (s.game.phase == LudoPhase.awaitingRoll) {
        await rollDice();
      } else {
        final token = LudoBot.chooseToken(s.game);
        if (token != null) await moveToken(token);
      }
    });
  }

  /// Time ran out for a human: the bot plays this action for them.
  Future<void> _autoPlayTurn() async {
    final gen = _gen;
    if (state.game.phase == LudoPhase.awaitingRoll) {
      await rollDice();
    } else {
      final token = LudoBot.chooseToken(state.game);
      if (token != null) await moveToken(token);
    }
    if (!_alive(gen)) return;
  }
}
