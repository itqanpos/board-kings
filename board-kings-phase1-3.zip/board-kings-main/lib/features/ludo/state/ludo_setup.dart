import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../engine/ludo_models.dart';

/// Config chosen in the setup screen. Null means "use the default game".
final ludoConfigProvider = StateProvider<LudoConfig?>((ref) => null);

/// Seconds allowed per action for human players (0 = no timer).
final ludoTurnSecondsProvider = StateProvider<int>((ref) => 0);

LudoConfig defaultLudoConfig() => LudoConfig(
      mode: LudoMode.freeForAll,
      players: const [
        LudoPlayerConfig(seat: 0, name: 'Player 1', avatarId: 0),
        LudoPlayerConfig(seat: 1, name: 'Computer 1', isBot: true, avatarId: 1),
        LudoPlayerConfig(seat: 2, name: 'Computer 2', isBot: true, avatarId: 2),
        LudoPlayerConfig(seat: 3, name: 'Computer 3', isBot: true, avatarId: 3),
      ],
    );
