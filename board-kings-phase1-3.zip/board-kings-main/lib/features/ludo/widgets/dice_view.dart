import 'package:flutter/material.dart';

import '../../../shared/widgets/pulse.dart';

/// Dice face drawn with a CustomPainter (no images). While [rolling] it
/// shakes and bounces; the face shown is whatever the controller feeds in.
class DiceView extends StatelessWidget {
  const DiceView({
    super.key,
    required this.value,
    required this.rolling,
    required this.accent,
    required this.enabled,
    required this.onTap,
    this.size = 84,
  });

  final int? value;
  final bool rolling;
  final Color accent;

  /// True when the player can roll now (adds a pulsing glow).
  final bool enabled;
  final VoidCallback? onTap;
  final double size;

  @override
  Widget build(BuildContext context) {
    Widget dice(double glow) {
      return AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        width: size,
        height: size,
        transformAlignment: Alignment.center,
        transform: Matrix4.identity()
          ..rotateZ(rolling ? (value ?? 1).isEven ? 0.22 : -0.22 : 0.0)
          ..scale(rolling ? 1.12 : 1.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size * 0.2),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFFFFF), Color(0xFFE0E0E0)],
          ),
          border: Border.all(color: accent, width: 3),
          boxShadow: [
            BoxShadow(color: Colors.black.withAlpha(140), blurRadius: 10, offset: const Offset(0, 6)),
            if (enabled)
              BoxShadow(color: accent.withAlpha((90 + 120 * glow).round()), blurRadius: 18, spreadRadius: 2),
          ],
        ),
        child: value == null
            ? Icon(Icons.casino, size: size * 0.55, color: Colors.black54)
            : CustomPaint(painter: _PipsPainter(value!)),
      );
    }

    return Semantics(
      button: true,
      enabled: enabled,
      label: 'dice',
      child: GestureDetector(
        onTap: enabled ? onTap : null,
        child: enabled ? Pulse(builder: (context, t) => dice(t)) : dice(0),
      ),
    );
  }
}

class _PipsPainter extends CustomPainter {
  _PipsPainter(this.value);

  final int value;

  // Pip positions on a 3x3 grid (0..2, 0..2).
  static const Map<int, List<List<int>>> _layout = {
    1: [[1, 1]],
    2: [[0, 0], [2, 2]],
    3: [[0, 0], [1, 1], [2, 2]],
    4: [[0, 0], [2, 0], [0, 2], [2, 2]],
    5: [[0, 0], [2, 0], [1, 1], [0, 2], [2, 2]],
    6: [[0, 0], [2, 0], [0, 1], [2, 1], [0, 2], [2, 2]],
  };

  @override
  void paint(Canvas canvas, Size size) {
    final pad = size.width * 0.22;
    final step = (size.width - 2 * pad) / 2;
    final paint = Paint()..color = const Color(0xFF212121);
    final isOne = value == 1;
    for (final p in _layout[value]!) {
      canvas.drawCircle(
        Offset(pad + p[0] * step, pad + p[1] * step),
        size.width * (isOne ? 0.13 : 0.09),
        isOne ? (Paint()..color = const Color(0xFFD32F2F)) : paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _PipsPainter old) => old.value != value;
}
