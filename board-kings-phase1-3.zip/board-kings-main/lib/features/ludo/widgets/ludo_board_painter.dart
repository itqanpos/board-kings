import 'dart:math';

import 'package:flutter/material.dart';

import '../engine/ludo_board.dart';
import 'ludo_palette.dart';

/// Paints the static Ludo board. It never changes, so it never repaints.
class LudoBoardPainter extends CustomPainter {
  const LudoBoardPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / LudoBoard.gridSize;
    final fill = Paint()..style = PaintingStyle.fill;
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.black.withAlpha(60);

    fill.color = const Color(0xFFFFFBF0);
    canvas.drawRect(Offset.zero & size, fill);

    // Bases.
    for (var seat = 0; seat < 4; seat++) {
      final o = LudoBoard.baseOrigin[seat];
      final rect = Rect.fromLTWH(o.x * cell, o.y * cell, 6 * cell, 6 * cell);
      fill.color = LudoPalette.seat[seat];
      canvas.drawRect(rect, fill);

      final inner = RRect.fromRectAndRadius(
        Rect.fromLTWH((o.x + 1) * cell, (o.y + 1) * cell, 4 * cell, 4 * cell),
        Radius.circular(cell * 0.5),
      );
      fill.color = const Color(0xFFFFFBF0);
      canvas.drawRRect(inner, fill);

      for (var t = 0; t < 4; t++) {
        final c = LudoBoard.centerOf(seat, LudoBoard.basePos, t);
        fill.color = LudoPalette.seatLight[seat];
        canvas.drawCircle(Offset(c.x * cell, c.y * cell), cell * 0.5, fill);
        final ring = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = LudoPalette.seat[seat].withAlpha(160);
        canvas.drawCircle(Offset(c.x * cell, c.y * cell), cell * 0.5, ring);
      }
    }

    void drawCell(int x, int y, Color color) {
      final rect = Rect.fromLTWH(x * cell, y * cell, cell, cell);
      fill.color = color;
      canvas.drawRect(rect, fill);
      canvas.drawRect(rect, line);
    }

    // Ring.
    for (var i = 0; i < LudoBoard.ring.length; i++) {
      final c = LudoBoard.ring[i];
      var color = const Color(0xFFFFFFFF);
      for (var seat = 0; seat < 4; seat++) {
        if (LudoBoard.startRingIndex[seat] == i) color = LudoPalette.seat[seat];
      }
      drawCell(c[0], c[1], color);
    }

    // Safe squares (stars on the non-start ones; start squares get a white star).
    for (final idx in LudoBoard.safeRingIndexes) {
      final c = LudoBoard.ring[idx];
      final isStart = LudoBoard.startRingIndex.contains(idx);
      _drawStar(canvas, Offset((c[0] + 0.5) * cell, (c[1] + 0.5) * cell), cell * 0.32,
          isStart ? Colors.white : const Color(0xFF9E9E9E));
    }

    // Home lanes.
    for (var seat = 0; seat < 4; seat++) {
      for (final c in LudoBoard.homeLane[seat]) {
        drawCell(c[0], c[1], LudoPalette.seat[seat]);
      }
    }

    // Centre triangles: red (left), green (top), blue (right), yellow (bottom).
    final cx = 7.5 * cell;
    final cy = 7.5 * cell;
    final tl = Offset(6 * cell, 6 * cell);
    final tr = Offset(9 * cell, 6 * cell);
    final br = Offset(9 * cell, 9 * cell);
    final bl = Offset(6 * cell, 9 * cell);
    final centre = Offset(cx, cy);
    void tri(Offset a, Offset b, int seat) {
      final path = Path()
        ..moveTo(a.dx, a.dy)
        ..lineTo(b.dx, b.dy)
        ..lineTo(centre.dx, centre.dy)
        ..close();
      fill.color = LudoPalette.seat[seat];
      canvas.drawPath(path, fill);
    }

    tri(bl, tl, 0); // red: left triangle
    tri(tl, tr, 1); // green: top
    tri(tr, br, 2); // blue: right
    tri(br, bl, 3); // yellow: bottom
    final diag = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = Colors.white;
    canvas.drawLine(tl, br, diag);
    canvas.drawLine(tr, bl, diag);
  }

  void _drawStar(Canvas canvas, Offset c, double r, Color color) {
    final path = Path();
    for (var i = 0; i < 10; i++) {
      final radius = i.isEven ? r : r * 0.45;
      final angle = -pi / 2 + i * pi / 5;
      final p = Offset(c.dx + radius * cos(angle), c.dy + radius * sin(angle));
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant LudoBoardPainter oldDelegate) => false;
}
