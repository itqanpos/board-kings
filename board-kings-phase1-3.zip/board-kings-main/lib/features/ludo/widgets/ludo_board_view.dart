import 'dart:math';

import 'package:flutter/material.dart';

import '../../../shared/widgets/pulse.dart';
import '../engine/ludo_board.dart';
import '../engine/ludo_models.dart';
import 'ludo_board_painter.dart';
import 'ludo_palette.dart';

/// Short visual effect played on the board (capture burst, token home).
class BoardEffect {
  const BoardEffect({required this.id, required this.at, required this.isCapture});

  final int id;
  final GridPoint at;
  final bool isCapture;
}

class LudoBoardView extends StatelessWidget {
  const LudoBoardView({
    super.key,
    required this.config,
    required this.positions,
    required this.movable,
    required this.onTapToken,
    this.effect,
  });

  final LudoConfig config;

  /// positions[seat][token] as displayed (may be mid-animation).
  final List<List<int>> positions;
  final Set<TokenRef> movable;
  final void Function(TokenRef token) onTapToken;
  final BoardEffect? effect;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      const frame = 8.0;
      final side = max(60.0, min(constraints.maxWidth, constraints.maxHeight) - 2 * frame);
      final cell = side / LudoBoard.gridSize;

      // Group tokens that share a square so they can be fanned out.
      final groups = <String, List<TokenRef>>{};
      final centers = <TokenRef, GridPoint>{};
      for (final seat in config.seats) {
        for (var t = 0; t < LudoBoard.tokensPerPlayer; t++) {
          final ref = TokenRef(seat, t);
          final c = LudoBoard.centerOf(seat, positions[seat][t], t);
          centers[ref] = c;
          final key = '${(c.x * 100).round()}_${(c.y * 100).round()}';
          groups.putIfAbsent(key, () => []).add(ref);
        }
      }

      final tokens = <Widget>[];
      final ordered = centers.keys.toList()
        ..sort((a, b) {
          final ma = movable.contains(a) ? 1 : 0;
          final mb = movable.contains(b) ? 1 : 0;
          return ma.compareTo(mb);
        });
      for (final ref in ordered) {
        final c = centers[ref]!;
        final key = '${(c.x * 100).round()}_${(c.y * 100).round()}';
        final group = groups[key]!;
        var dx = 0.0;
        var dy = 0.0;
        var scale = 1.0;
        if (group.length > 1) {
          final i = group.indexOf(ref);
          final angle = 2 * pi * i / group.length - pi / 4;
          dx = cos(angle) * 0.2;
          dy = sin(angle) * 0.2;
          scale = 0.74;
        }
        final tokenSize = cell * 0.8 * scale;
        tokens.add(AnimatedPositioned(
          key: ValueKey('token-${ref.seat}-${ref.index}'),
          duration: const Duration(milliseconds: 130),
          curve: Curves.linear,
          left: (c.x + dx) * cell - tokenSize / 2,
          top: (c.y + dy) * cell - tokenSize / 2,
          width: tokenSize,
          height: tokenSize,
          child: _Token(seat: ref.seat, canMove: movable.contains(ref)),
        ));
      }

      return Center(
        child: Container(
          padding: const EdgeInsets.all(frame),
          decoration: BoxDecoration(
            color: const Color(0xFF3E2723),
            borderRadius: BorderRadius.circular(14),
            boxShadow: const [
              BoxShadow(color: Colors.black87, blurRadius: 22, offset: Offset(0, 12)),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: SizedBox(
          width: side,
          height: side,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapUp: (details) {
              final gx = details.localPosition.dx / cell;
              final gy = details.localPosition.dy / cell;
              TokenRef? best;
              var bestDist = 1.0; // must tap within one cell of a movable token
              for (final ref in movable) {
                final c = centers[ref];
                if (c == null) continue;
                final d = sqrt(pow(c.x - gx, 2) + pow(c.y - gy, 2));
                if (d < bestDist) {
                  bestDist = d;
                  best = ref;
                }
              }
              if (best != null) onTapToken(best);
            },
            child: Stack(
              clipBehavior: Clip.hardEdge,
              children: [
                const RepaintBoundary(
                  child: CustomPaint(
                    size: Size.infinite,
                    painter: LudoBoardPainter(),
                  ),
                ),
                ...tokens,
                if (effect != null)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: TweenAnimationBuilder<double>(
                        key: ValueKey('effect-${effect!.id}'),
                        tween: Tween(begin: 0, end: 1),
                        duration: const Duration(milliseconds: 700),
                        builder: (context, t, _) => CustomPaint(
                          painter: _BurstPainter(
                            center: Offset(effect!.at.x * cell, effect!.at.y * cell),
                            cell: cell,
                            t: t,
                            color: effect!.isCapture
                                ? const Color(0xFFFF7043)
                                : const Color(0xFFFFD54F),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
            ),
          ),
        ),
      );
    });
  }
}

class _Token extends StatelessWidget {
  const _Token({required this.seat, required this.canMove});

  final int seat;
  final bool canMove;

  @override
  Widget build(BuildContext context) {
    if (!canMove) {
      return CustomPaint(painter: _TokenPainter(seat: seat, glow: 0));
    }
    return Pulse(
      builder: (context, t) => Transform.scale(
        scale: 1.0 + 0.18 * t,
        child: CustomPaint(painter: _TokenPainter(seat: seat, glow: t)),
      ),
    );
  }
}

class _TokenPainter extends CustomPainter {
  _TokenPainter({required this.seat, required this.glow});

  final int seat;
  final double glow;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    final color = LudoPalette.seat[seat];

    // shadow
    canvas.drawOval(
      Rect.fromCenter(center: c.translate(0, r * 0.18), width: r * 1.7, height: r * 1.5),
      Paint()..color = Colors.black.withAlpha(70),
    );
    if (glow > 0) {
      canvas.drawCircle(
          c, r * (1.05 + 0.2 * glow), Paint()..color = Colors.white.withAlpha((90 + 100 * glow).round()));
    }
    // body
    final body = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.35, -0.4),
        colors: [LudoPalette.seatLight[seat], color, LudoPalette.seatDark[seat]],
        stops: const [0.0, 0.55, 1.0],
      ).createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r * 0.92, body);
    canvas.drawCircle(
      c,
      r * 0.92,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = r * 0.14
        ..color = Colors.white,
    );
    // inner crown dot
    canvas.drawCircle(c, r * 0.28, Paint()..color = Colors.white.withAlpha(220));
  }

  @override
  bool shouldRepaint(covariant _TokenPainter old) => old.seat != seat || old.glow != glow;
}

class _BurstPainter extends CustomPainter {
  _BurstPainter({required this.center, required this.cell, required this.t, required this.color});

  final Offset center;
  final double cell;
  final double t;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final fade = (1 - t).clamp(0.0, 1.0);
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = cell * 0.18 * fade + 1
      ..color = color.withAlpha((fade * 255).round());
    canvas.drawCircle(center, cell * (0.3 + 1.3 * t), ring);
    final spoke = Paint()
      ..strokeWidth = cell * 0.08
      ..strokeCap = StrokeCap.round
      ..color = color.withAlpha((fade * 255).round());
    for (var i = 0; i < 8; i++) {
      final a = i * pi / 4;
      final r1 = cell * (0.4 + 0.9 * t);
      final r2 = cell * (0.65 + 1.3 * t);
      canvas.drawLine(center + Offset(cos(a) * r1, sin(a) * r1),
          center + Offset(cos(a) * r2, sin(a) * r2), spoke);
    }
  }

  @override
  bool shouldRepaint(covariant _BurstPainter old) => old.t != t;
}
