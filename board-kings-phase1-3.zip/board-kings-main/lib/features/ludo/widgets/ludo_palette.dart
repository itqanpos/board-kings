import 'package:flutter/material.dart';

class LudoPalette {
  LudoPalette._();

  static const List<Color> seat = [
    Color(0xFFE53935), // red
    Color(0xFF43A047), // green
    Color(0xFF1E88E5), // blue
    Color(0xFFFDD835), // yellow
  ];

  static const List<Color> seatDark = [
    Color(0xFF8E1B19),
    Color(0xFF1B5E20),
    Color(0xFF0D47A1),
    Color(0xFFB59B00),
  ];

  static const List<Color> seatLight = [
    Color(0xFFFFCDD2),
    Color(0xFFC8E6C9),
    Color(0xFFBBDEFB),
    Color(0xFFFFF59D),
  ];
}
