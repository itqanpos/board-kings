import 'package:flutter/material.dart';

import '../../../shared/widgets/avatar.dart';
import '../engine/ludo_models.dart';
import 'ludo_palette.dart';

/// Player card: avatar, name, tokens home, turn highlight and turn timer.
class LudoPlayerPanel extends StatelessWidget {
  const LudoPlayerPanel({
    super.key,
    required this.player,
    required this.active,
    required this.tokensHome,
    required this.homeLabel,
    required this.withdrawn,
    this.secondsLeft,
    this.rank,
  });

  final LudoPlayerConfig player;
  final bool active;
  final int tokensHome;
  final String homeLabel;
  final bool withdrawn;
  final int? secondsLeft;
  final int? rank;

  @override
  Widget build(BuildContext context) {
    final color = LudoPalette.seat[player.seat];
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 250),
      opacity: withdrawn ? 0.35 : (active ? 1 : 0.75),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: active ? color.withAlpha(50) : Colors.white.withAlpha(12),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: active ? color : Colors.white12, width: active ? 2 : 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                PlayerAvatar(
                  avatarId: player.avatarId,
                  size: active ? 48 : 40,
                  ringColor: color,
                  glow: active,
                ),
                if (player.isBot)
                  const PositionedDirectional(
                    end: -4,
                    bottom: -2,
                    child: CircleAvatar(
                      radius: 9,
                      backgroundColor: Colors.black87,
                      child: Icon(Icons.smart_toy, size: 11, color: Colors.white),
                    ),
                  ),
                if (rank != null)
                  PositionedDirectional(
                    start: -4,
                    top: -4,
                    child: CircleAvatar(
                      radius: 10,
                      backgroundColor: const Color(0xFFD4AF37),
                      child: Text('$rank',
                          style: const TextStyle(
                              fontSize: 11, fontWeight: FontWeight.bold, color: Colors.black)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            SizedBox(
              width: 74,
              child: Text(
                player.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: active ? FontWeight.bold : FontWeight.normal,
                  color: active ? Colors.white : Colors.white70,
                ),
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.flag, size: 12, color: color),
                const SizedBox(width: 2),
                Text(homeLabel, style: const TextStyle(fontSize: 11, color: Colors.white70)),
                if (secondsLeft != null && active) ...[
                  const SizedBox(width: 6),
                  Icon(Icons.timer, size: 12, color: secondsLeft! <= 5 ? Colors.redAccent : Colors.white70),
                  Text('$secondsLeft',
                      style: TextStyle(
                          fontSize: 11,
                          color: secondsLeft! <= 5 ? Colors.redAccent : Colors.white70)),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
