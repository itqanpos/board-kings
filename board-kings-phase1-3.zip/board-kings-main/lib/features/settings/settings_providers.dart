import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/services/sound_service.dart';
import '../../core/utils/dice_source.dart';

/// 'ar' (default, RTL) or 'en'. In-memory for now (no persistence layer yet).
final languageProvider = StateProvider<String>((ref) => 'ar');

final soundEnabledProvider = StateProvider<bool>((ref) => true);

final stringsProvider = Provider<Strings>((ref) => Strings(ref.watch(languageProvider)));

final soundServiceProvider =
    Provider<SoundService>((ref) => SoundService(enabled: ref.watch(soundEnabledProvider)));

/// Overridable in tests.
final diceSourceProvider = Provider<DiceSource>((ref) => SecureDiceSource());
