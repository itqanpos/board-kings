import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'settings_providers.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(stringsProvider);
    final lang = ref.watch(languageProvider);
    final sound = ref.watch(soundEnabledProvider);
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(onPressed: () => context.go('/')),
        title: Text(s.t('settings.title')),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(s.t('settings.language'),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                SegmentedButton<String>(
                  segments: [
                    ButtonSegment(value: 'ar', label: Text(s.t('settings.arabic'))),
                    ButtonSegment(value: 'en', label: Text(s.t('settings.english'))),
                  ],
                  selected: {lang},
                  onSelectionChanged: (v) =>
                      ref.read(languageProvider.notifier).state = v.first,
                ),
                const SizedBox(height: 24),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(s.t('settings.sound')),
                  subtitle: Text(s.t('settings.soundNote')),
                  value: sound,
                  onChanged: (v) => ref.read(soundEnabledProvider.notifier).state = v,
                ),
                const SizedBox(height: 8),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  enabled: false,
                  leading: const Icon(Icons.mic_off),
                  title: Text(s.t('settings.voice')),
                  subtitle: Text(s.t('settings.voiceNote')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
