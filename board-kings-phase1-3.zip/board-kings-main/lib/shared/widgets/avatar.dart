import 'package:flutter/material.dart';

/// Locally drawn avatar (no network images). [avatarId] picks colours/style.
class PlayerAvatar extends StatelessWidget {
  const PlayerAvatar({
    super.key,
    required this.avatarId,
    this.size = 44,
    this.ringColor,
    this.glow = false,
  });

  final int avatarId;
  final double size;
  final Color? ringColor;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: ringColor ?? Colors.white24, width: glow ? 3 : 2),
        boxShadow: glow && ringColor != null
            ? [BoxShadow(color: ringColor!.withAlpha(160), blurRadius: 12, spreadRadius: 2)]
            : const [],
      ),
      child: ClipOval(
        child: CustomPaint(painter: _AvatarPainter(avatarId)),
      ),
    );
  }
}

class _AvatarPainter extends CustomPainter {
  _AvatarPainter(this.id);

  final int id;

  static const List<Color> _bg = [
    Color(0xFF5C6BC0), Color(0xFF26A69A), Color(0xFFEF5350), Color(0xFFFFA726),
    Color(0xFF8D6E63), Color(0xFFAB47BC), Color(0xFF42A5F5), Color(0xFF9CCC65),
  ];
  static const List<Color> _skin = [
    Color(0xFFFFDBB4), Color(0xFFE0AC69), Color(0xFFC68642), Color(0xFF8D5524),
  ];
  static const List<Color> _hair = [
    Color(0xFF2B1B0E), Color(0xFF6B4423), Color(0xFFB5651D), Color(0xFF111111),
  ];
  static const List<Color> _shirt = [
    Color(0xFFFFFFFF), Color(0xFF263238), Color(0xFFFFEB3B), Color(0xFFE91E63),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final p = Paint()..style = PaintingStyle.fill;

    p.color = _bg[id % _bg.length];
    canvas.drawRect(Offset.zero & size, p);

    // shoulders
    p.color = _shirt[(id ~/ 3) % _shirt.length];
    canvas.drawOval(Rect.fromLTWH(w * 0.12, h * 0.68, w * 0.76, h * 0.55), p);

    // neck + face
    final skin = _skin[(id ~/ 2) % _skin.length];
    p.color = skin;
    canvas.drawRect(Rect.fromLTWH(w * 0.43, h * 0.55, w * 0.14, h * 0.18), p);
    final faceRect = Rect.fromCenter(
        center: Offset(w * 0.5, h * 0.42), width: w * 0.46, height: h * 0.5);
    canvas.drawOval(faceRect, p);

    // hair styles
    p.color = _hair[(id ~/ 5 + id) % _hair.length];
    switch (id % 4) {
      case 0: // short hair
        canvas.drawArc(faceRect.inflate(w * 0.02), 3.14159, 3.14159, true, p);
      case 1: // side swept
        canvas.drawArc(faceRect.inflate(w * 0.02), 3.3, 2.9, true, p);
        canvas.drawCircle(Offset(w * 0.32, h * 0.34), w * 0.08, p);
      case 2: // bun
        canvas.drawArc(faceRect.inflate(w * 0.02), 3.14159, 3.14159, true, p);
        canvas.drawCircle(Offset(w * 0.5, h * 0.12), w * 0.11, p);
      default: // cap
        canvas.drawArc(faceRect.inflate(w * 0.03), 3.14159, 3.14159, true, p);
        canvas.drawRect(Rect.fromLTWH(w * 0.22, h * 0.27, w * 0.56, h * 0.07), p);
    }

    // eyes + smile
    p.color = const Color(0xFF212121);
    canvas.drawCircle(Offset(w * 0.4, h * 0.42), w * 0.035, p);
    canvas.drawCircle(Offset(w * 0.6, h * 0.42), w * 0.035, p);
    final smile = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.03
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF212121);
    canvas.drawArc(
        Rect.fromCenter(center: Offset(w * 0.5, h * 0.5), width: w * 0.2, height: h * 0.14),
        0.2,
        2.7,
        false,
        smile);
  }

  @override
  bool shouldRepaint(covariant _AvatarPainter old) => old.id != id;
}
