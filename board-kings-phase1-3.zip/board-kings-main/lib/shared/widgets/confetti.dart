import 'dart:math';

import 'package:flutter/material.dart';

/// One-shot confetti burst used for victories. Purely cosmetic randomness.
class ConfettiOverlay extends StatefulWidget {
  const ConfettiOverlay({super.key, this.duration = const Duration(seconds: 4)});

  final Duration duration;

  @override
  State<ConfettiOverlay> createState() => _ConfettiOverlayState();
}

class _ConfettiOverlayState extends State<ConfettiOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<_Piece> _pieces;

  static const List<Color> _palette = [
    Color(0xFFE53935), Color(0xFF43A047), Color(0xFF1E88E5),
    Color(0xFFFDD835), Color(0xFFD4AF37), Color(0xFFFFFFFF),
  ];

  @override
  void initState() {
    super.initState();
    final rnd = Random(11);
    _pieces = List.generate(90, (i) {
      return _Piece(
        x: rnd.nextDouble(),
        delay: rnd.nextDouble() * 0.4,
        speed: 0.5 + rnd.nextDouble() * 0.7,
        sway: rnd.nextDouble() * 2 * pi,
        size: 5 + rnd.nextDouble() * 6,
        color: _palette[rnd.nextInt(_palette.length)],
        spin: rnd.nextDouble() * 6,
      );
    });
    _controller = AnimationController(vsync: this, duration: widget.duration)
      ..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          size: Size.infinite,
          painter: _ConfettiPainter(_pieces, _controller.value),
        ),
      ),
    );
  }
}

class _Piece {
  _Piece({
    required this.x,
    required this.delay,
    required this.speed,
    required this.sway,
    required this.size,
    required this.color,
    required this.spin,
  });

  final double x, delay, speed, sway, size, spin;
  final Color color;
}

class _ConfettiPainter extends CustomPainter {
  _ConfettiPainter(this.pieces, this.t);

  final List<_Piece> pieces;
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (final p in pieces) {
      final local = ((t - p.delay) / (1 - p.delay)).clamp(0.0, 1.0);
      if (local <= 0) continue;
      final y = local * p.speed * (size.height + 40) - 20;
      final x = p.x * size.width + sin(local * 6 + p.sway) * 24;
      paint.color = p.color.withAlpha(((1 - local * 0.6) * 255).round());
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(local * p.spin * 6);
      canvas.drawRect(
          Rect.fromCenter(center: Offset.zero, width: p.size, height: p.size * 0.6), paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter old) => old.t != t;
}
