import 'package:flutter/material.dart';

import '../../core/l10n/strings.dart';

Future<bool> confirmLeave(BuildContext context, Strings s) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(s.t('common.leaveTitle')),
      content: Text(s.t('common.leaveBody')),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: Text(s.t('common.cancel')),
        ),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(90, 44)),
          onPressed: () => Navigator.of(ctx).pop(true),
          child: Text(s.t('common.leave')),
        ),
      ],
    ),
  );
  return result ?? false;
}

Future<void> showRules(BuildContext context, Strings s, String game) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(s.t('rules.$game.title')),
      content: SingleChildScrollView(child: Text(s.t('rules.$game.body'))),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(),
          child: Text(s.t('common.back')),
        ),
      ],
    ),
  );
}
