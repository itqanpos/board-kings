import 'package:flutter/material.dart';

/// Repeating 0..1..0 animation for highlighting interactive things.
class Pulse extends StatefulWidget {
  const Pulse({super.key, required this.builder, this.duration = const Duration(milliseconds: 800)});

  final Widget Function(BuildContext context, double t) builder;
  final Duration duration;

  @override
  State<Pulse> createState() => _PulseState();
}

class _PulseState extends State<Pulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: widget.duration)..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) => widget.builder(context, Curves.easeInOut.transform(_c.value)),
    );
  }
}
