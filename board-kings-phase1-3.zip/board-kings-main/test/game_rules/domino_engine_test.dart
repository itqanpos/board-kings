import 'dart:math';

import 'package:board_kings/features/domino/engine/domino_bot.dart';
import 'package:board_kings/features/domino/engine/domino_engine.dart';
import 'package:board_kings/features/domino/engine/domino_models.dart';
import 'package:flutter_test/flutter_test.dart';

DominoTile t(int a, int b) => DominoTile(a, b);

DominoConfig cfg(int n, {DominoRules rules = const DominoRules()}) =>
    DominoConfig(names: [for (var i = 0; i < n; i++) 'P$i'], rules: rules);

DominoState round(
  List<List<DominoTile>> hands, {
  DominoRules rules = const DominoRules(),
  List<int>? scores,
}) =>
    DominoEngine.startRoundFromHands(
      cfg(hands.length, rules: rules),
      hands,
      round: 1,
      scores: scores ?? List<int>.filled(hands.length, 0),
      history: const [],
      version: 0,
    );

void main() {
  group('tiles and dealing', () {
    test('full set has 28 unique tiles', () {
      final set = DominoTile.fullSet();
      expect(set.length, 28);
      expect(set.toSet().length, 28);
    });

    test('tiles are normalised', () {
      expect(t(6, 2), t(2, 6));
      expect(() => DominoTile(7, 1), throwsArgumentError);
    });

    test('2 players get 7 tiles each', () {
      final hands = DominoEngine.deal(cfg(2), Random(1));
      expect(hands.map((h) => h.length), [7, 7]);
      expect(hands.expand((h) => h).toSet().length, 14);
    });

    test('3 and 4 players get 5 tiles each; rest is out of play', () {
      for (final n in [3, 4]) {
        final hands = DominoEngine.deal(cfg(n), Random(n));
        expect(hands.map((h) => h.length), List.filled(n, 5));
        expect(hands.expand((h) => h).toSet().length, n * 5);
      }
    });

    test('player count is validated', () {
      expect(() => cfg(1), throwsArgumentError);
      expect(() => cfg(5), throwsArgumentError);
    });
  });

  group('first player', () {
    test('highest double starts', () {
      final s = round([
        [t(3, 3), t(6, 5)],
        [t(5, 5), t(1, 2)],
      ]);
      expect(s.currentSeat, 1);
      expect(s.openingTile, t(5, 5));
    });

    test('without doubles the highest tile starts', () {
      final s = round([
        [t(6, 4), t(1, 2)],
        [t(6, 5), t(0, 1)],
      ]);
      expect(s.currentSeat, 1);
      expect(s.openingTile, t(5, 6));
    });

    test('equal pip totals are broken by the larger half', () {
      final s = round([
        [t(5, 2), t(0, 1)],
        [t(6, 1), t(0, 2)],
      ]);
      expect(s.openingTile, t(1, 6));
      expect(s.currentSeat, 1);
    });

    test('starter must open with the deciding tile (default rule)', () {
      final s = round([
        [t(5, 5), t(1, 2)],
        [t(3, 3), t(0, 1)],
      ]);
      expect(DominoEngine.legalMoves(s), [DominoMove(t(5, 5), DominoEnd.right)]);
      expect(() => DominoEngine.play(s, DominoMove(t(1, 2), DominoEnd.right)),
          throwsA(isA<DominoRuleException>()));
    });

    test('opening rule can be switched off', () {
      final s = round([
        [t(5, 5), t(1, 2)],
        [t(3, 3), t(0, 1)],
      ], rules: const DominoRules(forceOpeningTile: false));
      expect(DominoEngine.legalMoves(s).length, 2);
    });
  });

  group('moves', () {
    DominoState opened() {
      var s = round([
        [t(6, 6), t(6, 2), t(1, 2)],
        [t(6, 3), t(3, 4), t(0, 0)],
      ]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      return s;
    }

    test('matching tile can be placed on either end and is oriented', () {
      var s = opened();
      expect(s.leftEnd, 6);
      expect(s.rightEnd, 6);
      expect(s.currentSeat, 1);
      s = DominoEngine.play(s, DominoMove(t(3, 6), DominoEnd.left)).state;
      expect(s.leftEnd, 3);
      expect(s.rightEnd, 6);
      s = DominoEngine.play(s, DominoMove(t(2, 6), DominoEnd.right)).state;
      expect(s.rightEnd, 2);
      expect(s.board.length, 3);
    });

    test('non matching tile is rejected', () {
      final s = opened();
      expect(() => DominoEngine.play(s, DominoMove(t(3, 4), DominoEnd.left)),
          throwsA(isA<DominoRuleException>().having((e) => e.code, 'code', DominoErrorCode.illegalMove)));
    });

    test('a tile not in hand is rejected', () {
      final s = opened();
      expect(() => DominoEngine.play(s, DominoMove(t(1, 2), DominoEnd.left)),
          throwsA(isA<DominoRuleException>().having((e) => e.code, 'code', DominoErrorCode.tileNotInHand)));
    });

    test('duplicate action is rejected by version check', () {
      final s = opened();
      final move = DominoMove(t(3, 6), DominoEnd.left);
      final r = DominoEngine.play(s, move, expectedVersion: s.version);
      expect(r.state.version, s.version + 1);
      expect(() => DominoEngine.play(s, move, expectedVersion: r.state.version),
          throwsA(isA<DominoRuleException>().having((e) => e.code, 'code', DominoErrorCode.staleVersion)));
    });

    test('turn passes to the next player', () {
      final s = opened();
      expect(s.currentSeat, 1);
      final r = DominoEngine.play(s, DominoMove(t(3, 6), DominoEnd.left)).state;
      expect(r.currentSeat, 0);
    });
  });

  group('passing', () {
    test('cannot pass while a legal move exists', () {
      var s = round([
        [t(6, 6), t(6, 2)],
        [t(6, 3), t(0, 0)],
      ]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      expect(() => DominoEngine.pass(s),
          throwsA(isA<DominoRuleException>().having((e) => e.code, 'code', DominoErrorCode.mustPlay)));
    });

    test('must pass (and can pass) with no legal move', () {
      var s = round([
        [t(6, 6), t(1, 2), t(0, 2)],
        [t(3, 4), t(3, 5), t(0, 0)],
      ]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      expect(DominoEngine.legalMoves(s), isEmpty);
      final r = DominoEngine.pass(s);
      expect(r.state.currentSeat, 0);
      expect(r.state.consecutivePasses, 1);
    });

    test('a play resets the pass counter', () {
      var s = round([
        [t(6, 6), t(6, 1), t(0, 2)],
        [t(3, 4), t(1, 5), t(0, 0)],
      ]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      s = DominoEngine.pass(s).state; // seat 1 has no 6
      s = DominoEngine.play(s, DominoMove(t(1, 6), DominoEnd.left)).state;
      expect(s.consecutivePasses, 0);
    });
  });

  group('blocked rounds and scoring', () {
    DominoState blockedSetup({
      required List<DominoTile> h0,
      required List<DominoTile> h1,
      DominoRules rules = const DominoRules(),
    }) {
      var s = round([h0, h1], rules: rules);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      s = DominoEngine.pass(s).state;
      s = DominoEngine.pass(s).state;
      return s;
    }

    test('block after every player passed in a row; lowest hand wins', () {
      final s = blockedSetup(
        h0: [t(6, 6), t(1, 2)], // 3 left
        h1: [t(3, 4), t(3, 5)], // 15
      );
      expect(s.phase, DominoPhase.roundOver);
      expect(s.result, DominoRoundResult.blocked);
      expect(s.roundWinner, 0);
      expect(s.roundPoints, 15);
      expect(s.scores, [15, 0]);
    });

    test('difference scoring variant', () {
      final s = blockedSetup(
        h0: [t(6, 6), t(1, 2)],
        h1: [t(3, 4), t(3, 5)],
        rules: const DominoRules(blockPoints: BlockPoints.difference),
      );
      expect(s.roundPoints, 12);
    });

    test('tie on lowest total: nobody scores', () {
      final s = blockedSetup(
        h0: [t(6, 6), t(1, 2)], // 3
        h1: [t(0, 1), t(0, 2)], // 3
      );
      expect(s.result, DominoRoundResult.blockedTie);
      expect(s.roundWinner, isNull);
      expect(s.scores, [0, 0]);
      expect(s.phase, DominoPhase.roundOver);
    });

    test('block needs all players: 3 players need 3 passes', () {
      var s = round([
        [t(6, 6), t(1, 2)],
        [t(3, 4), t(3, 5)],
        [t(0, 1), t(2, 3)],
      ]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      s = DominoEngine.pass(s).state;
      s = DominoEngine.pass(s).state;
      expect(s.phase, DominoPhase.playing);
      s = DominoEngine.pass(s).state;
      expect(s.phase, DominoPhase.roundOver);
      expect(s.roundWinner, 0); // 3 pips vs 15 vs 6
    });

    test('going out ends the round; winner scores the opponents pips', () {
      var s = round([
        [t(6, 6)],
        [t(1, 2), t(3, 4)],
      ]);
      final r = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right));
      s = r.state;
      expect(s.result, DominoRoundResult.domino);
      expect(s.roundWinner, 0);
      expect(s.roundPoints, 10);
      expect(s.scores, [10, 0]);
      expect(r.events.map((e) => e.type), contains(DominoEventType.roundWon));
    });

    test('match ends at the target score', () {
      var s = round([
        [t(6, 6)],
        [t(1, 2), t(3, 4)],
      ], scores: [95, 40]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      expect(s.phase, DominoPhase.matchOver);
      expect(s.matchWinner, 0);
      expect(s.scores[0], 105);
    });

    test('no actions after the round or match is over', () {
      var s = round([
        [t(6, 6)],
        [t(1, 2)],
      ]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      expect(() => DominoEngine.pass(s), throwsA(isA<DominoRuleException>()));
      expect(() => DominoEngine.play(s, DominoMove(t(1, 2), DominoEnd.left)),
          throwsA(isA<DominoRuleException>()));
    });
  });

  group('rounds', () {
    test('next round only after the round is over; scores carry over', () {
      var s = DominoEngine.newMatch(cfg(2), Random(3));
      expect(() => DominoEngine.startNextRound(s, Random(4)),
          throwsA(isA<DominoRuleException>()));
      final fake = round([
        [t(6, 6)],
        [t(1, 2)],
      ]);
      final over = DominoEngine.play(fake, DominoMove(t(6, 6), DominoEnd.right)).state;
      s = DominoEngine.startNextRound(over, Random(4));
      expect(s.round, 2);
      expect(s.phase, DominoPhase.playing);
      expect(s.scores, over.scores);
      expect(s.board, isEmpty);
      expect(s.hands.map((h) => h.length), [7, 7]);
    });
  });

  group('privacy', () {
    test('public view exposes hand sizes, not tiles', () {
      final s = round([
        [t(6, 6), t(1, 2)],
        [t(3, 4), t(3, 5)],
      ]);
      final v = s.toPublicView();
      expect(v.handSizes, [2, 2]);
      expect(v.board, isEmpty);
      expect(v.scores, [0, 0]);
    });
  });

  group('bots and randomised matches', () {
    test('bot only returns legal moves', () {
      final s = round([
        [t(6, 6), t(6, 2), t(1, 2)],
        [t(6, 3), t(3, 4), t(0, 0)],
      ]);
      final m = DominoBot.chooseMove(s)!;
      expect(DominoEngine.legalMoves(s), contains(m));
    });

    test('bot returns null when it must pass', () {
      var s = round([
        [t(6, 6), t(1, 2)],
        [t(3, 4), t(3, 5)],
      ]);
      s = DominoEngine.play(s, DominoMove(t(6, 6), DominoEnd.right)).state;
      expect(DominoBot.chooseMove(s), isNull);
    });

    test('200 random matches terminate and conserve tiles', () {
      for (var game = 0; game < 200; game++) {
        final rng = Random(game);
        final n = 2 + game % 3;
        var s = DominoEngine.newMatch(cfg(n), rng);
        var rounds = 0;
        var guard = 0;
        while (s.phase != DominoPhase.matchOver) {
          if (++guard > 100000) fail('game $game did not terminate');
          if (s.phase == DominoPhase.roundOver) {
            if (++rounds > 1000) fail('too many rounds');
            s = DominoEngine.startNextRound(s, rng);
            continue;
          }
          final moves = DominoEngine.legalMoves(s);
          if (moves.isEmpty) {
            s = DominoEngine.pass(s).state;
          } else {
            s = DominoEngine.play(s, moves[rng.nextInt(moves.length)]).state;
          }
          final all = [
            ...s.hands.expand((h) => h),
            ...s.board.map((p) => p.tile),
          ];
          expect(all.toSet().length, all.length, reason: 'duplicate tile');
          expect(all.length, n * cfg(n).handSize);
          // chain integrity: touching halves match
          for (var i = 0; i + 1 < s.board.length; i++) {
            expect(s.board[i].right, s.board[i + 1].left);
          }
        }
        expect(s.matchWinner, isNotNull);
        expect(s.scores[s.matchWinner!], greaterThanOrEqualTo(100));
      }
    });
  });
}
