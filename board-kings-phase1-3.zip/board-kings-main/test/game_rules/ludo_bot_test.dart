import 'dart:math';

import 'package:board_kings/core/utils/dice_source.dart';
import 'package:board_kings/features/ludo/engine/ludo_bot.dart';
import 'package:board_kings/features/ludo/engine/ludo_engine.dart';
import 'package:board_kings/features/ludo/engine/ludo_models.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/ludo_helpers.dart';

void main() {
  test('bot returns null when no move is awaited', () {
    expect(LudoBot.chooseToken(LudoEngine.newGame(ffaConfig())), isNull);
  });

  test('bot prefers a capture', () {
    final s0 = stateWith(ffaConfig(), {
      0: [5, 20, -1, -1],
      1: [rel(1, 20), -1, -1, -1],
    });
    final s = LudoEngine.roll(s0, 2).state; // token0 5->7 (abs 20) captures
    expect(LudoBot.chooseToken(s), 0);
  });

  test('bot finishes a token when it can', () {
    final s0 = stateWith(ffaConfig(), {
      0: [53, 10, -1, -1],
    });
    final s = LudoEngine.roll(s0, 3).state;
    expect(LudoBot.chooseToken(s), 0);
  });

  test('bot always picks a legal token', () {
    final rng = Random(5);
    var s = LudoEngine.newGame(ffaConfig());
    for (var i = 0; i < 3000 && !s.isFinished; i++) {
      if (s.phase == LudoPhase.awaitingRoll) {
        s = LudoEngine.roll(s, rng.nextInt(6) + 1).state;
      } else {
        final token = LudoBot.chooseToken(s)!;
        expect(LudoEngine.currentLegalTokens(s), contains(token));
        s = LudoEngine.move(s, token).state;
      }
    }
  });

  test('dice source yields only 1..6 and every face', () {
    final dice = SecureDiceSource(Random(1));
    final seen = <int>{};
    for (var i = 0; i < 600; i++) {
      final v = dice.roll();
      expect(v, inInclusiveRange(1, 6));
      seen.add(v);
    }
    expect(seen.length, 6);
  });
}
