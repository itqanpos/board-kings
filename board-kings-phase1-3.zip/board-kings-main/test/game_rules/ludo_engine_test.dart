import 'dart:math';

import 'package:board_kings/features/ludo/engine/ludo_board.dart';
import 'package:board_kings/features/ludo/engine/ludo_engine.dart';
import 'package:board_kings/features/ludo/engine/ludo_models.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/ludo_helpers.dart';

void main() {
  group('board geometry', () {
    test('ring has 52 unique, connected squares', () {
      expect(LudoBoard.ring.length, 52);
      expect(LudoBoard.ring.map((c) => '${c[0]},${c[1]}').toSet().length, 52);
      for (var i = 0; i < 52; i++) {
        final a = LudoBoard.ring[i];
        final b = LudoBoard.ring[(i + 1) % 52];
        expect((a[0] - b[0]).abs() <= 1 && (a[1] - b[1]).abs() <= 1, isTrue,
            reason: 'ring[$i] -> ring[${(i + 1) % 52}] must touch');
      }
    });

    test('start squares are in each colour arm', () {
      List<int> startCell(int seat) =>
          LudoBoard.ring[LudoBoard.ringIndex(seat, 0)];
      expect(startCell(0), [1, 6]); // red, top-left
      expect(startCell(1), [8, 1]); // green, top-right
      expect(startCell(2), [13, 8]); // blue, bottom-right
      expect(startCell(3), [6, 13]); // yellow, bottom-left
    });

    test('pos 50 is the square just before each home lane', () {
      List<int> cell(int seat) => LudoBoard.ring[LudoBoard.ringIndex(seat, 50)];
      expect(cell(0), [0, 7]);
      expect(cell(1), [7, 0]);
      expect(cell(2), [14, 7]);
      expect(cell(3), [7, 14]);
    });

    test('there are exactly 8 safe squares', () {
      expect(LudoBoard.safeRingIndexes.toSet().length, 8);
    });

    test('every position maps to a point inside the grid', () {
      for (var seat = 0; seat < 4; seat++) {
        for (var t = 0; t < 4; t++) {
          for (var pos = -1; pos <= 56; pos++) {
            final p = LudoBoard.centerOf(seat, pos, t);
            expect(p.x, inInclusiveRange(0, 15));
            expect(p.y, inInclusiveRange(0, 15));
          }
        }
      }
    });
  });

  group('config', () {
    test('rejects invalid player counts and seats', () {
      expect(() => ffaConfig([0]), throwsArgumentError);
      expect(() => ffaConfig([0, 0]), throwsArgumentError);
      expect(() => ffaConfig([0, 4]), throwsArgumentError);
      expect(
          () => LudoConfig(mode: LudoMode.teams2v2, players: [
                const LudoPlayerConfig(seat: 0, name: 'a'),
                const LudoPlayerConfig(seat: 2, name: 'b'),
              ]),
          throwsArgumentError);
    });
  });

  group('leaving base', () {
    test('a token leaves base only on a 6', () {
      var s = LudoEngine.newGame(ffaConfig());
      final step = LudoEngine.roll(s, 6);
      s = step.state;
      expect(s.phase, LudoPhase.awaitingMove);
      expect(LudoEngine.currentLegalTokens(s), [0, 1, 2, 3]);
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[0][0], 0);
    });

    test('non-6 with all tokens in base: no legal move, turn passes', () {
      final s = LudoEngine.newGame(ffaConfig());
      final step = LudoEngine.roll(s, 3);
      expect(step.events.map((e) => e.type),
          contains(LudoEventType.noLegalMoves));
      expect(step.state.currentSeat, 1);
      expect(step.state.phase, LudoPhase.awaitingRoll);
    });

    test('moving a base token with a non-6 is rejected', () {
      final s0 = stateWith(ffaConfig(), {
        0: [10, -1, -1, -1]
      });
      final s = LudoEngine.roll(s0, 3).state;
      expect(() => LudoEngine.move(s, 1),
          throwsA(isA<LudoRuleException>().having((e) => e.code, 'code', LudoErrorCode.illegalMove)));
    });
  });

  group('turn flow', () {
    test('move requires a prior roll', () {
      final s = LudoEngine.newGame(ffaConfig());
      expect(() => LudoEngine.move(s, 0), throwsA(isA<LudoRuleException>()));
    });

    test('cannot roll twice before moving', () {
      final s0 = stateWith(ffaConfig(), {
        0: [10, -1, -1, -1]
      });
      final s = LudoEngine.roll(s0, 3).state;
      expect(() => LudoEngine.roll(s, 4), throwsA(isA<LudoRuleException>()));
    });

    test('invalid dice values are rejected', () {
      final s = LudoEngine.newGame(ffaConfig());
      expect(() => LudoEngine.roll(s, 0), throwsA(isA<LudoRuleException>()));
      expect(() => LudoEngine.roll(s, 7), throwsA(isA<LudoRuleException>()));
    });

    test('token moves by the rolled value and the turn passes', () {
      final s0 = stateWith(ffaConfig(), {
        0: [5, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 4).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[0][0], 9);
      expect(s.currentSeat, 1);
    });

    test('a 6 grants an extra turn to the same player', () {
      final s0 = stateWith(ffaConfig(), {
        0: [5, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 6).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[0][0], 11);
      expect(s.currentSeat, 0);
      expect(s.phase, LudoPhase.awaitingRoll);
    });

    test('turn order is clockwise and skips seats that are not playing', () {
      final s0 = stateWith(ffaConfig([0, 2]), {
        0: [5, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 2).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.currentSeat, 2);
    });

    test('duplicate move is rejected (phase and version checks)', () {
      final s0 = stateWith(ffaConfig(), {
        0: [5, -1, -1, -1]
      });
      final rolled = LudoEngine.roll(s0, 4);
      final moved = LudoEngine.move(rolled.state, 0, expectedVersion: rolled.state.version);
      // Replaying the same move on the resulting state fails: not awaiting a move.
      expect(() => LudoEngine.move(moved.state, 0), throwsA(isA<LudoRuleException>()));
      // Replaying it on the old state with its old version also fails (stale).
      expect(
          () => LudoEngine.move(moved.state, 0, expectedVersion: rolled.state.version),
          throwsA(isA<LudoRuleException>().having((e) => e.code, 'code', LudoErrorCode.staleVersion)));
    });

    test('concurrent conflicting actions: second one with the same version loses', () {
      final s0 = stateWith(ffaConfig(), {
        0: [5, 7, -1, -1]
      });
      final rolled = LudoEngine.roll(s0, 4).state;
      final first = LudoEngine.move(rolled, 0, expectedVersion: rolled.version);
      expect(first.state.version, rolled.version + 1);
      // A second client still holding `rolled`'s version tries to move token 1.
      expect(
          () => LudoEngine.move(first.state, 1, expectedVersion: rolled.version),
          throwsA(isA<LudoRuleException>().having((e) => e.code, 'code', LudoErrorCode.staleVersion)));
    });
  });

  group('capture and safe squares', () {
    test('landing on an opponent captures it', () {
      final cfg = ffaConfig();
      // seat0 pos 5 -> abs 18; moving 2 lands on abs 20 (not safe).
      final s0 = stateWith(cfg, {
        0: [5, -1, -1, -1],
        1: [rel(1, 20), -1, -1, -1],
      });
      var s = LudoEngine.roll(s0, 2).state;
      final step = LudoEngine.move(s, 0);
      s = step.state;
      expect(s.positions[0][0], 7);
      expect(s.positions[1][0], -1);
      final cap = step.events.firstWhere((e) => e.type == LudoEventType.tokenCaptured);
      expect(cap.victims, [const TokenRef(1, 0)]);
    });

    test('all opponent tokens stacked on the square are captured', () {
      final cfg = ffaConfig();
      final s0 = stateWith(cfg, {
        0: [5, -1, -1, -1],
        1: [rel(1, 20), rel(1, 20), -1, -1],
      });
      var s = LudoEngine.roll(s0, 2).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[1], [-1, -1, -1, -1]);
    });

    test('no capture on a safe square', () {
      final cfg = ffaConfig();
      // abs 21 is safe. seat0 pos 5 (abs 18) + 3 = abs 21.
      expect(LudoBoard.isSafeRingIndex(21), isTrue);
      final s0 = stateWith(cfg, {
        0: [5, -1, -1, -1],
        1: [rel(1, 21), -1, -1, -1],
      });
      var s = LudoEngine.roll(s0, 3).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[0][0], 8);
      expect(s.positions[1][0], rel(1, 21));
    });

    test('a token leaving base onto an occupied start square captures nothing (safe)', () {
      final cfg = ffaConfig();
      // seat1 token sits on seat0's start square (abs 13, safe).
      final s0 = stateWith(cfg, {
        1: [rel(1, 13), -1, -1, -1],
      });
      var s = LudoEngine.roll(s0, 6).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[0][0], 0);
      expect(s.positions[1][0], rel(1, 13));
    });

    test('tokens in the home lane are never captured', () {
      final cfg = ffaConfig();
      final s0 = stateWith(cfg, {
        0: [45, -1, -1, -1],
        1: [52, -1, -1, -1], // lane
      });
      var s = LudoEngine.roll(s0, 3).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[1][0], 52);
    });
  });

  group('finishing', () {
    test('exact roll reaches the centre', () {
      final s0 = stateWith(ffaConfig(), {
        0: [53, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 3).state;
      final step = LudoEngine.move(s, 0);
      expect(step.state.positions[0][0], LudoBoard.finishPos);
      expect(step.events.map((e) => e.type), contains(LudoEventType.tokenFinished));
    });

    test('overshooting is illegal; with no other move the turn passes', () {
      final s0 = stateWith(ffaConfig(), {
        0: [53, -1, -1, -1]
      });
      final step = LudoEngine.roll(s0, 4);
      expect(step.events.map((e) => e.type), contains(LudoEventType.noLegalMoves));
      expect(step.state.currentSeat, 1);
      expect(step.state.positions[0][0], 53);
    });

    test('overshooting token is rejected even when another token can move', () {
      final s0 = stateWith(ffaConfig(), {
        0: [53, 10, -1, -1]
      });
      final s = LudoEngine.roll(s0, 4).state;
      expect(LudoEngine.currentLegalTokens(s), [1]);
      expect(() => LudoEngine.move(s, 0), throwsA(isA<LudoRuleException>()));
    });

    test('a finished token cannot move again', () {
      final s0 = stateWith(ffaConfig(), {
        0: [56, 10, -1, -1]
      });
      final s = LudoEngine.roll(s0, 1).state;
      expect(LudoEngine.currentLegalTokens(s), [1]);
    });

    test('ring position 50 + 6 jumps straight to the centre (exact distance)', () {
      final s0 = stateWith(ffaConfig(), {
        0: [50, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 6).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[0][0], 56);
    });
  });

  group('three consecutive sixes', () {
    test('third six ends the turn and sends the moved ring token to base', () {
      final s0 = stateWith(ffaConfig(), {
        0: [10, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 6).state;
      s = LudoEngine.move(s, 0).state; // 16, extra turn
      expect(s.currentSeat, 0);
      s = LudoEngine.roll(s, 6).state;
      s = LudoEngine.move(s, 0).state; // 22, extra turn
      expect(s.currentSeat, 0);
      final rolled = LudoEngine.roll(s, 6);
      expect(rolled.events.map((e) => e.type), contains(LudoEventType.tripleSix));
      final step = LudoEngine.move(rolled.state, 0);
      expect(step.events.map((e) => e.type), contains(LudoEventType.tripleSixPenalty));
      expect(step.state.positions[0][0], -1);
      expect(step.state.currentSeat, 1);
      expect(step.state.consecutiveSixes, 0);
    });

    test('a token that reaches the home lane with the third six stays there', () {
      final s0 = stateWith(ffaConfig(), {
        0: [47, -1, -1, -1]
      }, consecutiveSixes: 2);
      var s = LudoEngine.roll(s0, 6).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[0][0], 53);
      expect(s.currentSeat, 1);
    });

    test('third six with no legal move just ends the turn', () {
      final s0 = stateWith(ffaConfig(), {
        0: [56, 56, 56, 53]
      }, consecutiveSixes: 2);
      final step = LudoEngine.roll(s0, 6);
      expect(step.state.currentSeat, 1);
    });

    test('a non-6 resets the six counter', () {
      final s0 = stateWith(ffaConfig(), {
        0: [10, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 6).state;
      s = LudoEngine.move(s, 0).state;
      s = LudoEngine.roll(s, 2).state;
      expect(s.consecutiveSixes, 0);
    });
  });

  group('winning', () {
    test('2 players: the match ends when one finishes', () {
      final s0 = stateWith(ffaConfig([0, 2]), {
        0: [56, 56, 56, 55]
      });
      var s = LudoEngine.roll(s0, 1).state;
      final step = LudoEngine.move(s, 3);
      s = step.state;
      expect(s.isFinished, isTrue);
      expect(s.winnerTeam, 0);
      expect(s.ranking, [0, 2]);
      expect(step.events.map((e) => e.type), contains(LudoEventType.gameOver));
      expect(() => LudoEngine.roll(s, 3), throwsA(isA<LudoRuleException>()));
    });

    test('4 players: ends after three players finished, ranking is complete', () {
      final s0 = stateWith(ffaConfig(), {
        0: [56, 56, 56, 56],
        1: [56, 56, 56, 56],
        2: [56, 56, 56, 55],
        3: [20, -1, -1, -1],
      }, currentSeat: 2, finishOrder: [0, 1]);
      var s = LudoEngine.roll(s0, 1).state;
      s = LudoEngine.move(s, 3).state;
      expect(s.isFinished, isTrue);
      expect(s.ranking, [0, 1, 2, 3]);
      expect(s.winnerTeam, 0);
    });

    test('4 players: a single finisher does not end the match; finished player is skipped', () {
      final s0 = stateWith(ffaConfig(), {
        0: [56, 56, 56, 55],
      });
      var s = LudoEngine.roll(s0, 1).state;
      s = LudoEngine.move(s, 3).state;
      expect(s.isFinished, isFalse);
      expect(s.finishOrder, [0]);
      expect(s.currentSeat, 1); // no extra turn after finishing
      // seat 3 -> next must skip seat 0
      var t = stateWith(ffaConfig(), {
        0: [56, 56, 56, 56],
      }, currentSeat: 3, finishOrder: [0]);
      t = LudoEngine.roll(t, 2).state; // no legal move, passes
      expect(t.currentSeat, 1);
    });
  });

  group('2v2 team rules', () {
    test('a player never captures a teammate; shares the square instead', () {
      final cfg = teamsConfig();
      final s0 = stateWith(cfg, {
        0: [5, -1, -1, -1],
        2: [rel(2, 20), -1, -1, -1],
      });
      var s = LudoEngine.roll(s0, 2).state;
      final step = LudoEngine.move(s, 0);
      expect(step.state.positions[0][0], 7);
      expect(step.state.positions[2][0], rel(2, 20));
      expect(step.events.map((e) => e.type), isNot(contains(LudoEventType.tokenCaptured)));
    });

    test('opponents are still captured in 2v2', () {
      final cfg = teamsConfig();
      final s0 = stateWith(cfg, {
        0: [5, -1, -1, -1],
        1: [rel(1, 20), -1, -1, -1],
        2: [rel(2, 20), -1, -1, -1],
      });
      var s = LudoEngine.roll(s0, 2).state;
      s = LudoEngine.move(s, 0).state;
      expect(s.positions[1][0], -1);
      expect(s.positions[2][0], rel(2, 20));
    });

    test('the team wins when both partners brought all tokens home', () {
      final cfg = teamsConfig();
      final s0 = stateWith(cfg, {
        0: [56, 56, 56, 56],
        2: [56, 56, 56, 55],
        1: [20, -1, -1, -1],
      }, currentSeat: 2, finishOrder: [0]);
      var s = LudoEngine.roll(s0, 1).state;
      s = LudoEngine.move(s, 3).state;
      expect(s.isFinished, isTrue);
      expect(s.winnerTeam, 0);
    });

    test('one finished partner alone does not win the match', () {
      final cfg = teamsConfig();
      final s0 = stateWith(cfg, {
        0: [56, 56, 56, 55],
      });
      var s = LudoEngine.roll(s0, 1).state;
      s = LudoEngine.move(s, 3).state;
      expect(s.isFinished, isFalse);
    });
  });

  group('withdrawal, disconnect and reconnect', () {
    test('withdrawing the current player passes the turn', () {
      final s0 = LudoEngine.newGame(ffaConfig());
      final s = LudoEngine.withdraw(s0, 0).state;
      expect(s.withdrawn, {0});
      expect(s.currentSeat, 1);
      expect(s.isFinished, isFalse);
    });

    test('match ends when only one player is left', () {
      var s = LudoEngine.newGame(ffaConfig([0, 1, 2]));
      s = LudoEngine.withdraw(s, 0).state;
      s = LudoEngine.withdraw(s, 1).state;
      expect(s.isFinished, isTrue);
      expect(s.ranking.first, 2);
      expect(s.ranking.last, 0);
    });

    test('withdraw is idempotent', () {
      var s = LudoEngine.newGame(ffaConfig());
      s = LudoEngine.withdraw(s, 3).state;
      final again = LudoEngine.withdraw(s, 3);
      expect(again.events, isEmpty);
      expect(again.state.version, s.version);
    });

    test('team with both players withdrawn loses; other team wins', () {
      var s = LudoEngine.newGame(teamsConfig());
      s = LudoEngine.withdraw(s, 0).state;
      expect(s.isFinished, isFalse);
      s = LudoEngine.withdraw(s, 2).state;
      expect(s.isFinished, isTrue);
      expect(s.winnerTeam, 1);
    });

    test('disconnect keeps the game state; reconnecting resumes the same turn', () {
      final s0 = stateWith(ffaConfig(), {
        0: [5, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 4).state;
      final before = s;
      s = LudoEngine.setConnection(s, 0, false).state;
      expect(s.disconnected, {0});
      expect(s.positions, before.positions);
      expect(s.phase, LudoPhase.awaitingMove);
      expect(s.dice, 4);
      s = LudoEngine.setConnection(s, 0, true).state;
      expect(s.disconnected, isEmpty);
      s = LudoEngine.move(s, 0).state; // still the same pending move
      expect(s.positions[0][0], 9);
    });

    test('connection changes are idempotent', () {
      final s0 = LudoEngine.newGame(ffaConfig());
      final step = LudoEngine.setConnection(s0, 1, true);
      expect(step.events, isEmpty);
    });
  });

  group('match history', () {
    test('every action is appended to the history', () {
      final s0 = stateWith(ffaConfig(), {
        0: [5, -1, -1, -1]
      });
      var s = LudoEngine.roll(s0, 4).state;
      s = LudoEngine.move(s, 0).state;
      final types = s.history.map((e) => e.type).toList();
      expect(types, containsAllInOrder([
        LudoEventType.diceRolled,
        LudoEventType.tokenMoved,
        LudoEventType.turnChanged,
      ]));
    });
  });

  group('randomised full games (invariants)', () {
    test('200 random games always terminate with consistent state', () {
      for (var game = 0; game < 200; game++) {
        final rng = Random(game);
        final mode = game % 4 == 0 ? LudoMode.teams2v2 : LudoMode.freeForAll;
        final cfg = mode == LudoMode.teams2v2
            ? teamsConfig()
            : ffaConfig([
                [0, 2],
                [0, 1, 2],
                [0, 1, 2, 3],
              ][game % 3]);
        var s = LudoEngine.newGame(cfg);
        var steps = 0;
        while (!s.isFinished) {
          if (++steps > 40000) fail('game $game did not terminate');
          if (s.phase == LudoPhase.awaitingRoll) {
            s = LudoEngine.roll(s, rng.nextInt(6) + 1).state;
          } else {
            final legal = LudoEngine.currentLegalTokens(s);
            expect(legal, isNotEmpty);
            s = LudoEngine.move(s, legal[rng.nextInt(legal.length)]).state;
          }
          for (final seat in cfg.seats) {
            for (final p in s.positions[seat]) {
              expect(p, inInclusiveRange(-1, 56));
            }
          }
        }
        expect(s.ranking.toSet().length, cfg.seats.length);
        expect(s.winnerTeam, isNotNull);
      }
    });
  });
}
