import 'package:board_kings/features/ludo/engine/ludo_board.dart';
import 'package:board_kings/features/ludo/engine/ludo_models.dart';
import 'package:board_kings/features/ludo/engine/ludo_engine.dart';

LudoConfig ffaConfig([List<int> seats = const [0, 1, 2, 3]]) => LudoConfig(
      mode: LudoMode.freeForAll,
      players: [for (final s in seats) LudoPlayerConfig(seat: s, name: 'P$s')],
    );

LudoConfig teamsConfig() => LudoConfig(
      mode: LudoMode.teams2v2,
      players: [for (final s in [0, 1, 2, 3]) LudoPlayerConfig(seat: s, name: 'P$s')],
    );

/// New game with some token positions overridden: {seat: [p0,p1,p2,p3]}.
LudoState stateWith(
  LudoConfig config,
  Map<int, List<int>> positions, {
  int? currentSeat,
  int? consecutiveSixes,
  List<int>? finishOrder,
}) {
  final base = LudoEngine.newGame(config);
  final pos = [for (final row in base.positions) List<int>.of(row)];
  positions.forEach((seat, row) => pos[seat] = List<int>.of(row));
  return base.copyWith(
    positions: pos,
    currentSeat: currentSeat,
    consecutiveSixes: consecutiveSixes,
    finishOrder: finishOrder,
  );
}

/// Relative position of [seat] for an absolute ring index.
int rel(int seat, int absRingIndex) =>
    (absRingIndex - LudoBoard.startRingIndex[seat] + LudoBoard.ringLength) %
    LudoBoard.ringLength;
