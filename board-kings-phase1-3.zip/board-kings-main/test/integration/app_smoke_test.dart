import 'package:board_kings/app/app.dart';
import 'package:board_kings/features/ludo/screens/ludo_game_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('home -> Ludo setup -> Ludo game screen', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: BoardKingsApp()));
    await tester.pumpAndSettle();
    expect(find.text('BOARD KINGS'), findsOneWidget);

    await tester.tap(find.text('لودو'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('ابدأ اللعب'));
    // The dice pulses forever, so never use pumpAndSettle on the game screen.
    await tester.pump(const Duration(milliseconds: 400));
    expect(find.byType(LudoGameScreen), findsOneWidget);
  });

  testWidgets('home -> Domino setup screen', (tester) async {
    // The Domino game screen is not opened here: a bot may start the round and
    // schedule delayed actions, which would leave timers pending at test end.
    await tester.pumpWidget(const ProviderScope(child: BoardKingsApp()));
    await tester.pumpAndSettle();
    await tester.tap(find.text('دومينو'));
    await tester.pumpAndSettle();
    expect(find.text('ابدأ اللعب'), findsOneWidget);
  });
}
