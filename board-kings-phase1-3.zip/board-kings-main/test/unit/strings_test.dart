import 'dart:io';

import 'package:board_kings/core/l10n/strings.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Arabic and English define exactly the same keys', () {
    expect(Strings.arabic.keys.toSet(), Strings.english.keys.toSet());
  });

  test('every {placeholder} is the same in both languages', () {
    final re = RegExp(r'\{(\w+)\}');
    for (final key in Strings.english.keys) {
      final en = re.allMatches(Strings.english[key]!).map((m) => m.group(1)).toSet();
      final ar = re.allMatches(Strings.arabic[key]!).map((m) => m.group(1)).toSet();
      expect(ar, en, reason: 'placeholders differ for $key');
    }
  });

  test('every literal key used in lib/ exists', () {
    final used = <String>{};
    final re = RegExp(r"""\.t\(\s*'([\w.]+)'""");
    for (final f in Directory('lib')
        .listSync(recursive: true)
        .whereType<File>()
        .where((f) => f.path.endsWith('.dart'))) {
      for (final m in re.allMatches(f.readAsStringSync())) {
        used.add(m.group(1)!);
      }
    }
    expect(used, isNotEmpty);
    final missing = used.where((k) => !Strings.english.containsKey(k)).toList();
    expect(missing, isEmpty);
  });

  test('missing keys fall back to the key itself', () {
    expect(const Strings('en').t('no.such.key'), 'no.such.key');
  });

  test('arguments are substituted', () {
    expect(const Strings('en').t('common.player', {'n': '3'}), 'Player 3');
  });
}
